import { Circular } from '../types';
import { Megaphone, Calendar, FileText, Download, Tag, Search } from 'lucide-react';
import { useState, FormEvent } from 'react';

interface NoticeBoardProps {
  circulars: Circular[];
  onAddCircular?: (newCircular: Circular) => void;
  showAdminActions?: boolean;
}

export function NoticeBoard({ circulars, onAddCircular, showAdminActions = false }: NoticeBoardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('All');
  
  // Custom dialog or inline form for adding circulars
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'Academic' | 'Administrative' | 'Event' | 'Holiday'>('Academic');
  const [newContent, setNewContent] = useState('');
  const [newAttachment, setNewAttachment] = useState('');

  const handleCreate = (e: FormEvent) => {
    e.preventDefault();
    if (!newTitle || !newContent) return;

    if (onAddCircular) {
      onAddCircular({
        id: `CIRC-${Date.now().toString().slice(-4)}`,
        title: newTitle,
        category: newCategory,
        content: newContent,
        date: new Date().toISOString().split('T')[0],
        sender: 'Super Admin Council',
        attachmentName: newAttachment ? `${newAttachment}.pdf` : undefined
      });
    }

    // Reset inputs
    setNewTitle('');
    setNewContent('');
    setNewAttachment('');
    setShowAddForm(false);
  };

  const filteredCirculars = circulars.filter((circ) => {
    const matchesSearch = circ.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          circ.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'All' || circ.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (cat: Circular['category']) => {
    switch (cat) {
      case 'Academic': return 'bg-sky-100 text-sky-800 border-sky-200';
      case 'Administrative': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Event': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Holiday': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-rose-500" /> Digital Notice Board & Circulars
        </h3>
        {showAdminActions && onAddCircular && (
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="bg-indigo-600 cursor-pointer hover:bg-indigo-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-all shadow-sm"
          >
            {showAddForm ? 'Close Document Form' : '➕ Broadcast New Circular'}
          </button>
        )}
      </div>

      {/* Admin Broadcast Portal Form */}
      {showAddForm && (
        <form onSubmit={handleCreate} className="bg-slate-50 p-6 rounded-xl border border-indigo-100 shadow-sm space-y-4">
          <h4 className="text-sm font-bold text-indigo-955 uppercase tracking-wide">
            Publish Official School Decree
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">Notice Title / Subject Heading</label>
              <input
                type="text"
                placeholder="e.g. Autumn Break Declaration"
                className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                value={newTitle}
                onChange={e => setNewTitle(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-500 mb-1">Notice Classification Category</label>
              <select
                className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                value={newCategory}
                onChange={e => setNewCategory(e.target.value as any)}
              >
                <option value="Academic">Academic Schedule</option>
                <option value="Administrative">Administrative Notification</option>
                <option value="Event">Extra-Curricular Event Announcement</option>
                <option value="Holiday">Vacation / Assembly Announcement</option>
              </select>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Circular Decree Content (Markdowns or Text)</label>
            <textarea
              placeholder="Provide complete descriptions regarding dates, timings, classes affected, and other operational guidelines for parents and staff..."
              className="w-full text-sm border border-slate-200 rounded-lg p-2.5 h-24 bg-white"
              value={newContent}
              onChange={e => setNewContent(e.target.value)}
              required
            ></textarea>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1">Attach Reference Standard PDF Document name (Optional)</label>
            <input
              type="file"
              accept=".jpg,.jpeg,.png,.pdf"
              className="w-full text-xs border border-slate-200 rounded-lg p-1.5 bg-white file:mr-4 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
              onChange={e => {
                if (e.target.files && e.target.files[0]) {
                  // We simulate uploading and retaining the file name minus extension logic, just use the raw name
                  setNewAttachment(e.target.files[0].name.replace(/\.[^/.]+$/, ""));
                }
              }}
            />
          </div>
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs py-2 px-5 rounded-lg transition-colors shadow"
          >
            Publish Live Notice Board
          </button>
        </form>
      )}

      {/* Notice Board Search and Filtering */}
      <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col md:flex-row items-center gap-4">
        <div className="flex-1 w-full relative">
          <Search className="absolute left-3 top-2.5 text-slate-400 h-4 w-4" />
          <input
            type="text"
            placeholder="Type keyword, title or guideline contents to search..."
            className="w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/10 placeholder-slate-400"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="flex items-center space-x-2 w-full md:w-auto overflow-x-auto whitespace-nowrap">
          <span className="text-xs text-slate-400 font-medium whitespace-nowrap">Filter:</span>
          {['All', 'Academic', 'Administrative', 'Event', 'Holiday'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`text-xs px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                filterCategory === cat
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Notices Feed List */}
      <div className="space-y-4">
        {filteredCirculars.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-100 text-slate-400 text-sm">
            No notices match your selected categories.
          </div>
        ) : (
          filteredCirculars.map((circ) => (
            <div key={circ.id} className="p-5 bg-white rounded-xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-4 items-start relative hover:border-slate-200 transition-colors">
              <div className="flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md border ${getCategoryColor(circ.category)}`}>
                    {circ.category}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                    <Calendar className="h-3.5 w-3.5" /> {circ.date}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">
                    Posted by: <strong className="text-slate-600 font-medium">{circ.sender}</strong>
                  </span>
                </div>
                
                <h4 className="text-base font-bold text-slate-800">{circ.title}</h4>
                <p className="text-sm text-slate-600 whitespace-pre-wrap leading-relaxed">{circ.content}</p>

                {circ.attachmentName && (
                  <div className="flex items-center gap-2 pt-2">
                    <span className="inline-flex items-center gap-1.5 text-xs text-indigo-600 bg-indigo-50 border border-indigo-100 px-3 py-1.5 rounded-lg font-medium hover:bg-indigo-100 cursor-pointer">
                      <FileText className="h-3.5 w-3.5" />
                      {circ.attachmentName}
                      <Download className="h-3 w-3 ml-1" />
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">(Simulated Reference PDF)</span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
