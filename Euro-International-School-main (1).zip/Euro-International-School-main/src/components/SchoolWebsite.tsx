import { useState } from 'react';
import { initialGallery } from '../data/mockData';
import { 
  BookOpen, 
  Award, 
  Sparkles, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ChevronRight, 
  ShieldCheck, 
  Users, 
  Heart, 
  Play, 
  School,
  FileSpreadsheet,
  GraduationCap
} from 'lucide-react';
import eisLogo from '../assets/images/regenerated_image_1782733247045.png';

interface SchoolWebsiteProps {
  onEnterPortal: () => void;
}

export function SchoolWebsite({ onEnterPortal }: SchoolWebsiteProps) {
  const [activeTab, setActiveTab] = useState<'Home' | 'Academics' | 'Admissions' | 'Gallery'>('Home');

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans">
      {/* Top Banner Alert / Announcement */}
      <div className="bg-slate-900 text-white text-xs py-2 px-4 flex flex-col sm:flex-row items-center justify-between gap-2 border-b border-amber-400">
        <div className="flex items-center gap-2">
          <span className="bg-amber-400 text-slate-950 px-1.5 py-0.5 rounded text-[10px] font-bold uppercase animate-pulse">Admissions Open</span>
          <span>Admissions ongoing for Session 2026-27 (Pre-Nursery to Grade XI)</span>
        </div>
        <div className="flex items-center gap-4 text-slate-300">
          <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> +91-88160-88160</span>
          <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> Dharuhera, HR, IN</span>
        </div>
      </div>

      {/* Primary Header */}
      <header className="bg-white/95 backdrop-blur shadow-sm sticky top-0 z-40 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 flex items-center justify-center rounded-md shadow-sm border border-slate-100 overflow-hidden bg-white">
              <img src={eisLogo} alt="EIS Logo" className="w-full h-full object-cover mix-blend-multiply" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-black text-slate-900 tracking-tight leading-none">
                EURO INTERNATIONAL
              </h1>
              <p className="text-[10px] md:text-xs font-semibold text-amber-500 uppercase tracking-widest mt-0.5">
                School, Dharuhera - Sector 6
              </p>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="hidden md:flex items-center space-x-8">
            {(['Home', 'Academics', 'Admissions', 'Gallery'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`text-sm font-semibold transition-colors cursor-pointer ${
                  activeTab === tab
                    ? 'text-indigo-600 border-b-2 border-indigo-600 pb-1'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </nav>

          {/* CTA Hub */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onEnterPortal}
              className="bg-indigo-600 text-white text-xs md:text-sm font-bold px-5 py-2.5 rounded-xl hover:bg-indigo-700 transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/10 border border-indigo-500/10 cursor-pointer hover:scale-[1.02] active:scale-95"
            >
              School Management Portal
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Body content according to Active Tab */}
      {activeTab === 'Home' && (
        <>
          {/* Hero Banner Section */}
          <section className="relative overflow-hidden bg-slate-950 text-white min-h-[500px] flex items-center py-16">
            <div className="absolute inset-0">
              <img
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1920&q=80"
                alt="EIS Dharuhera Campus"
                className="w-full h-full object-cover opacity-25 filter grayscale"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/80 to-transparent"></div>
            </div>
            
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center gap-1.5 bg-amber-400/10 border border-amber-400/30 text-amber-400 text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
                  <Sparkles className="w-3.5 h-3.5" /> Best-in-Class CBSE Curriculum
                </div>
                <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-white leading-tight tracking-tight">
                  Excellence in <br />
                  <span className="text-amber-400">Academics</span> & <br />
                  Character Development
                </h2>
                <p className="text-slate-300 text-sm md:text-base leading-relaxed max-w-lg">
                  At Euro International School, Dharuhera, we integrate holistic cognitive frameworks, progressive robotics/AI labs, and premium sport infrastructures to cultivate the global torchbearers of tomorrow.
                </p>
                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <button
                    onClick={() => setActiveTab('Admissions')}
                    className="bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-sm px-6 py-3 rounded-xl transition-colors shadow-lg cursor-pointer flex items-center gap-1"
                  >
                    Admission Procedures
                    <ChevronRight className="w-4 h-4 text-slate-950" />
                  </button>
                  <button
                    onClick={onEnterPortal}
                    className="bg-white/10 hover:bg-white/20 text-white font-bold text-sm px-6 py-3 rounded-xl transition-all border border-white/20 cursor-pointer shadow-sm"
                  >
                    Explore Campus Portal
                  </button>
                </div>
              </div>

              {/* Stat Bento Highlights Box */}
              <div className="grid grid-cols-2 gap-4 lg:pl-8">
                <div className="p-6 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <span className="text-3xl font-black text-amber-400 tracking-tight">100%</span>
                    <h5 className="text-sm font-semibold text-white mt-1">CBSE Board Success</h5>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Historically topping district boards across core mathematics and sciences.</p>
                </div>
                <div className="p-6 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <span className="text-3xl font-black text-indigo-400 tracking-tight">1:18</span>
                    <h5 className="text-sm font-semibold text-white mt-1">Teacher-Student Ratio</h5>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Ensuring individualized mentorship and tracking diagnostics for each child.</p>
                </div>
                <div className="p-6 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 flex flex-col justify-between text-left">
                  <div>
                    <span className="text-3xl font-black text-emerald-400 tracking-tight">15+</span>
                    <h5 className="text-sm font-semibold text-white mt-1">Hobby Club Spheres</h5>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Robotics, debating, classical music orchestration, skating, and coding programs.</p>
                </div>
                <div className="p-6 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 flex flex-col justify-between">
                  <div>
                    <span className="text-3xl font-black text-rose-400 tracking-tight">16+</span>
                    <h5 className="text-sm font-semibold text-white mt-1">GPS Armed Transports</h5>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">Realtime transit feeds and safety governess attendants across Rewari/Dharuhera regions.</p>
                </div>
              </div>
            </div>
          </section>

          {/* Pillars of Euro Advantage */}
          <section className="py-20 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
              <span className="text-xs text-indigo-600 font-bold uppercase tracking-widest bg-indigo-50 px-3 py-1.5 rounded-full inline-block">
                The EIS Pedagogy
              </span>
              <h3 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
                Our Foundational Pillars for Progressive Learning
              </h3>
              <p className="text-sm text-slate-500 max-w-xl mx-auto leading-relaxed">
                Balancing strict core syllabus with interactive inquiry-driven assignments and critical-thinking projects.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-8 text-left">
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100/60 hover:-translate-y-1 transition-transform">
                  <div className="bg-indigo-100 text-indigo-700 h-12 w-12 rounded-xl flex items-center justify-center mb-4">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-800 mb-2">Immersive Academic Rigor</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Personalized study worksheets, weekly periodic test revisions, and specialized boards grooming by highly vetted senior faculty with years of excellence track.
                  </p>
                </div>

                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100/60 hover:-translate-y-1 transition-transform">
                  <div className="bg-amber-100 text-amber-700 h-12 w-12 rounded-xl flex items-center justify-center mb-4">
                    <Award className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-800 mb-2">Sports & Co-curricular Mastery</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    State of art synthetic skating rinks, football field, open courts, taekwondo mentors, and vocal orchestras hosting district level championships.
                  </p>
                </div>

                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100/60 hover:-translate-y-1 transition-transform">
                  <div className="bg-emerald-100 text-emerald-700 h-12 w-12 rounded-xl flex items-center justify-center mb-4">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-800 mb-2">Ultra-Secured Digital Infrastructure</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Complete integration of real-time child tracking, digital leave approvals, parent-teacher messenger loops, and fully digitized fee-clearances.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* Quick Notice board banner */}
          <section className="bg-slate-50 py-16 border-t border-slate-100">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
              <div className="md:col-span-1 space-y-4 text-left">
                <span className="text-xs text-rose-600 font-bold uppercase tracking-wider bg-rose-50 px-2.5 py-1 rounded-full">
                  Broadcast Hub
                </span>
                <h3 className="text-xl md:text-2xl font-black text-slate-800 leading-tight">
                  Always Stay Informed
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Notice updates regarding PA-1, bus schedules, holidays, and event guidelines are pushed in real time onto our Campus portal notices segment.
                </p>
                <button
                  onClick={onEnterPortal}
                  className="text-xs text-indigo-600 font-bold flex items-center gap-1 hover:text-indigo-700 cursor-pointer"
                >
                  View Interactive Notice Board &rarr;
                </button>
              </div>

              {/* Mini Notice Board view */}
              <div className="md:col-span-2 space-y-3 bg-white p-5 rounded-2xl border border-slate-200/50 shadow-sm text-left">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <span className="text-xs font-bold text-slate-500">RECENT RELEASES</span>
                  <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
                </div>
                <div className="space-y-3 font-sans">
                  <div className="p-2.5 hover:bg-slate-50 rounded-lg transition-colors border-l-4 border-amber-400">
                    <div className="text-[10px] text-slate-400 font-mono">MAY 26, 2026</div>
                    <h5 className="text-xs font-black text-slate-800 mt-0.5">PA-1 Examination Schedule Heatwave Rescheduled</h5>
                    <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">Postponed PA-1 schedule starts June 15th to safeguard student health.</p>
                  </div>
                  <div className="p-2.5 hover:bg-slate-50 rounded-lg transition-colors border-l-4 border-indigo-400">
                    <div className="text-[10px] text-slate-400 font-mono">MAY 20, 2026</div>
                    <h5 className="text-xs font-black text-slate-800 mt-0.5">Primary admissions commencing for grade XI academic segments</h5>
                    <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">Register offline or view prospectus documentation packages.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Contact, Location & Admission Call */}
          <footer className="bg-slate-900 border-t border-slate-800 text-white py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="md:col-span-1 space-y-4">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-md bg-white flex items-center justify-center overflow-hidden">
                    <img src={eisLogo} alt="EIS Logo" className="w-full h-full object-cover mix-blend-multiply" />
                  </div>
                  <h4 className="text-base font-black">EURO DHARUHERA</h4>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Sector-6, NH-48 Expressway Bypass Crossing, Dharuhera, Haryana. Shaping international standard intellect since 2012.
                </p>
                <div className="flex space-x-2 text-slate-400">
                  <span className="h-8 w-8 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 transition-colors cursor-pointer"><Phone className="w-4 h-4" /></span>
                  <span className="h-8 w-8 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-slate-700 transition-colors cursor-pointer"><Mail className="w-4 h-4" /></span>
                </div>
              </div>

              <div>
                <h5 className="text-sm font-bold border-b border-slate-800 pb-2 mb-4">Admissions Info</h5>
                <ul className="space-y-2 text-xs text-slate-400">
                  <li><span className="hover:text-white cursor-pointer">&bull; Prospectus Guide Book</span></li>
                  <li><span className="hover:text-white cursor-pointer">&bull; Registration Details Form</span></li>
                  <li><span className="hover:text-white cursor-pointer">&bull; Fees Guidelines</span></li>
                  <li><span className="hover:text-white cursor-pointer">&bull; Sibling References Benefits</span></li>
                </ul>
              </div>

              <div>
                <h5 className="text-sm font-bold border-b border-slate-800 pb-2 mb-4">Portals Access</h5>
                <ul className="space-y-2 text-xs text-slate-400">
                  <li><button onClick={onEnterPortal} className="hover:text-white cursor-pointer hover:underline text-left">&bull; Parents & Students Desk</button></li>
                  <li><button onClick={onEnterPortal} className="hover:text-white cursor-pointer hover:underline text-left">&bull; Mentors & Teachers Cockpit</button></li>
                  <li><button onClick={onEnterPortal} className="hover:text-white cursor-pointer hover:underline text-left">&bull; Super Admin Workspace</button></li>
                  <li><button onClick={onEnterPortal} className="hover:text-white cursor-pointer hover:underline text-left">&bull; Accountants & Transport Specialist</button></li>
                </ul>
              </div>

              <div className="space-y-3">
                <h5 className="text-sm font-bold border-b border-slate-800 pb-2 mb-4">Campus Map Location</h5>
                <div className="w-full h-24 rounded-lg bg-slate-800 overflow-hidden relative border border-slate-700">
                  {/* Mock coordinate grid suggesting map location */}
                  <div className="absolute inset-0 bg-slate-950 flex flex-col items-center justify-center p-2 text-center text-[10px] text-slate-400">
                    <MapPin className="text-rose-500 w-5 h-5 mb-1" />
                    <span>EIS Sector 6 Dharuhera</span>
                    <span className="text-[8px] text-slate-500">(Near NH-48 Bypass, HR)</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800 pt-8 mt-8 text-center text-xs text-slate-500">
              <p>&copy; {new Date().getFullYear()} Euro International School, Dharuhera. Managed by EIS Council. All Rights Reserved.</p>
              <p className="mt-1 text-[10px] text-slate-600 font-mono">Designed for Premium Web & Mobile Responsive Portals</p>
            </div>
          </footer>
        </>
      )}

      {activeTab === 'Academics' && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[500px]">
          <div className="space-y-4 text-left max-w-xl mb-12">
            <span className="text-xs text-indigo-600 font-bold uppercase tracking-widest bg-indigo-50 px-3 py-1.5 rounded-full inline-block">Curriculum Overview</span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Vibrant Academics</h2>
            <p className="text-sm text-slate-500 leading-relaxed">
              We promote intellectual vigor, analytical exploration and customized skill milestones mapped to modern standard CBSE criteria.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            <div className="p-6 bg-white rounded-2xl border border-slate-100 shadow-sm space-y-3">
              <h4 className="text-lg font-bold text-slate-800">Primary Foundation (Pre-Nursery to V)</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Emphasis is on sensory motor integration, motor coordination, fundamental phonetics, basic numerical arrays, logical cognitive games, and interactive puppet storytelling environments.
              </p>
              <ul className="text-xs text-indigo-600 font-semibold space-y-1">
                <li>&bull; Experiential Activity Class Rooms</li>
                <li>&bull; Language Acquisition Programs</li>
                <li>&bull; Art & Clay Modelling Studio Interventions</li>
              </ul>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-100 shadow-sm space-y-3">
              <h4 className="text-lg font-bold text-slate-800">Middle Wing (VI to VIII)</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Nurturing inquiry mechanisms, introduction to robust laboratory experiments, computer coding fundamentals (Blockly, HTML/Python basics), and holistic historical events.
              </p>
              <ul className="text-xs text-indigo-600 font-semibold space-y-1">
                <li>&bull; STEM & Robotics Design Clubs</li>
                <li>&bull; Inter-House debating panels</li>
                <li>&bull; Science and Social exhibitions in campus grounds</li>
              </ul>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-100 shadow-sm space-y-3">
              <h4 className="text-lg font-bold text-slate-800">Secondary & Senior Secondary (IX to X / XI Science & Commerce)</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Strict grooming for boards under expert board assessors. Focus is on advanced sciences, mathematics, statistical analysis, accounting and core computer sciences.
              </p>
              <ul className="text-xs text-indigo-600 font-semibold space-y-1">
                <li>&bull; Career guidance programs & webinars</li>
                <li>&bull; Customized mock board drills with detailed corrections</li>
                <li>&bull; High-end physics, chemistry and engineering computing hubs</li>
              </ul>
            </div>

            <div className="p-6 bg-slate-900 text-white rounded-2xl border border-slate-800/60 shadow flex flex-col justify-between">
              <div className="space-y-3">
                <div className="text-amber-400 font-bold text-xs uppercase tracking-wide">Digital Classroom Portal</div>
                <h4 className="text-lg font-bold">Comprehensive Daily Syncs</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Parents can stay mapped with continuous assessments. View teacher schedules, download assignments daily, request approvals for leaves, and track live bus feeds.
                </p>
              </div>
              <button 
                onClick={onEnterPortal}
                className="bg-amber-400 hover:bg-amber-500 text-slate-950 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors mt-4 self-start cursor-pointer"
              >
                Launch Campus Pro Workspace
              </button>
            </div>
          </div>
        </section>
      )}

      {activeTab === 'Admissions' && (
        <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[500px]">
          <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden text-left">
            <div className="bg-slate-900 p-8 text-white relative">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <GraduationCap className="w-40 h-40" />
              </div>
              <span className="text-xs uppercase font-extrabold tracking-widest text-amber-400">Join Euro International school cohort</span>
              <h2 className="text-3xl font-black mt-2">Registration and Admission Guidelines</h2>
              <p className="text-slate-300 text-xs md:text-sm mt-2 max-w-xl">
                We simplify the process of enrollment to help your child begin their pathway towards excellence.
              </p>
            </div>

            <div className="p-8 space-y-8 font-sans">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-xl font-black text-indigo-600 font-mono">01</span>
                  <h4 className="text-sm font-bold text-slate-800">Online/Offline Registration</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Obtain the registration packet from the school admissions counter or download it online. Fill out the records securely.
                  </p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-xl font-black text-indigo-600 font-mono">02</span>
                  <h4 className="text-sm font-bold text-slate-800">Child Interaction Metric</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    A friendly, stress-free reading/interaction loop to map the child\'s base capabilities and match them to ideal tutor guidance.
                  </p>
                </div>
                <div className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="text-xl font-black text-indigo-600 font-mono">03</span>
                  <h4 className="text-sm font-bold text-slate-800">Document Submission</h4>
                  <p className="text-[11px] text-slate-500 leading-relaxed">
                    Submit the Birth certificate, past progress files, transfer logs, and identity copies of parents to complete onboarding files.
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 space-y-4">
                <h4 className="text-base font-bold text-slate-800">Prerequisite Enclosure Documents Checklist</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-600">
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>6 passport-sized photographs of the applicant child</span></div>
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>Copy of Aadhaar Card (Student and Parents)</span></div>
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>Official Birth Certificate from Municipal Corporation</span></div>
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>Previous School Progress Report Card (if applicable)</span></div>
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>Original Transfer Certificate (TC) signed by Education Board</span></div>
                  <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></div> <span>Address verification records (Electricity / Gas receipt / Registry file)</span></div>
                </div>
              </div>

              <div className="bg-amber-50 p-4 rounded-xl border border-amber-200/40 text-slate-700 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="text-left space-y-1">
                  <h5 className="text-xs font-bold text-amber-800 uppercase tracking-wide">Quick Admissions Helpline Desk</h5>
                  <p className="text-[11px] text-amber-900/80">Connect with an counselor expert directly regarding syllabus choices, quotas, and transport limits.</p>
                </div>
                <div className="flex gap-2">
                  <a href="tel:+918816088160" className="bg-slate-900 text-white text-xs font-bold px-4 py-2 rounded-lg cursor-pointer hover:bg-slate-800">Call: +91 88160 88160</a>
                  <a href="mailto:admissions@eurodharuhera.edu.in" className="bg-white border border-slate-300 text-slate-800 text-xs font-bold px-4 py-2 rounded-lg cursor-pointer hover:bg-slate-50">Email Admissions</a>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {activeTab === 'Gallery' && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 min-h-[500px]">
          <div className="space-y-4 text-left mb-8">
            <span className="text-xs text-indigo-600 font-bold uppercase tracking-widest bg-indigo-50 px-3 py-1.5 rounded-full inline-block">Visual Showcase</span>
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">Vibrant Campus Gallery</h2>
            <p className="text-sm text-slate-500 leading-relaxed max-w-xl">
              Captures from dynamic inter-house sports meets, advanced robotics tournaments, interactive class labs, and clean campus infrastructures.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
            {initialGallery.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm group hover:border-slate-200 hover:shadow transition-all">
                <div className="h-48 overflow-hidden relative">
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-3 left-3 bg-slate-950/80 backdrop-blur-md text-[10px] text-white font-bold uppercase tracking-wider px-2.5 py-1 rounded-md">
                    {item.category}
                  </span>
                </div>
                <div className="p-4 space-y-1">
                  <h4 className="text-sm font-bold text-slate-800 line-clamp-1">{item.title}</h4>
                  <div className="text-[10px] text-slate-400 font-mono">Event Captured: {item.date}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
