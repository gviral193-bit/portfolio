import { useState, useRef, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  UserRole, 
  Homework, 
  Circular, 
  Exam, 
  FeeInvoice, 
  LeaveRequest, 
  ChatMessage, 
  BusRoute 
} from '../types';
import { 
  mockUsers, 
  initialHomework, 
  initialCirculars, 
  initialExams, 
  mockTimetablesByClass, 
  parentStudentAttendance, 
  initialInvoices, 
  initialLeaves, 
  initialMessages, 
  mockBusRoute 
} from '../data/mockData';
import { TransportMap } from './TransportMap';
import { NoticeBoard } from './NoticeBoard';
import { 
  BookOpen, 
  Calendar, 
  CalendarDays,
  DollarSign, 
  Megaphone, 
  User as UserIcon, 
  Users, 
  MapPin, 
  Sparkles, 
  CheckCircle, 
  CheckCircle2, 
  Clock, 
  Send, 
  Check, 
  X, 
  FileText, 
  Layout, 
  Award, 
  Navigation, 
  Plus, 
  CreditCard, 
  UserCheck, 
  Eye, 
  CheckSquare, 
  AlertCircle, 
  GraduationCap, 
  ArrowLeft,
  Briefcase,
  Layers,
  Phone,
  ChevronRight,
  Shield,
  Moon,
  Sun
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import eisLogo from '../assets/images/regenerated_image_1782733247045.png';

function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error(error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue] as const;
}

interface PortalSimulatorProps {
  onExitPortal: () => void;
}

export function PortalSimulator({ onExitPortal }: PortalSimulatorProps) {
  // Synchronized state-based users directory for dynamic admin management
  const [campusUsers, setCampusUsers] = useLocalStorage<User[]>('EIS_campusUsers', [
    {
      id: 'USR_STUDENT_01',
      name: 'Aarav Kumar',
      email: 'aarav.kumar@eurodharuhera.edu.in',
      role: 'STUDENT',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        class: 'Grade 10-A',
        rollNo: 'EIS-10A-14',
        phone: '9412398765',
        busRoute: 'Route-5B',
        gender: 'Male',
        admissionNo: 'EIS-2024-0482'
      }
    },
    {
      id: 'USR_STUDENT_02',
      name: 'Ananya Kumar',
      email: 'ananya.kumar@eurodharuhera.edu.in',
      role: 'STUDENT',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        class: 'Grade 8-B',
        rollNo: 'EIS-8B-07',
        phone: '9412398765',
        busRoute: 'Route-5B',
        gender: 'Female',
        admissionNo: 'EIS-2026-0021'
      }
    },
    {
      id: 'USR_TEACH_01',
      name: 'Mrs. Sunita Rao',
      email: 'sunita.math@eurodharuhera.edu.in',
      role: 'TEACHER',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        class: 'Grade 10-A',
        employeeId: 'EIS-TCH-104',
        phone: '9812345678',
        designation: 'Head of Mathematics Department',
        gender: 'Female',
        assignedSubject: 'Mathematics',
        classTeacherOf: 'Grade 10-A'
      }
    },
    {
      id: 'USR_STUDENT_03',
      name: 'Rahul Rao',
      email: 'rahul.rao@eurodharuhera.edu.in',
      role: 'STUDENT',
      avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        class: 'Grade 10-A',
        rollNo: 'EIS-10A-19',
        phone: '9812345678',
        busRoute: 'Route-5C',
        gender: 'Male',
        admissionNo: 'EIS-2024-0104'
      }
    },
    {
      id: 'USR_ADMIN_01',
      name: 'Mr. Rajesh Sharma',
      email: 'admin@eurodharuhera.edu.in',
      role: 'ADMIN',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        designation: 'Managing Director & Super Admin',
        employeeId: 'EIS-ADM-001',
        phone: '9876543210',
        gender: 'Male'
      }
    },
    {
      id: 'USR_STAFF_01',
      name: 'Mr. Vinod Yadav',
      email: 'transport@eurodharuhera.edu.in',
      role: 'STAFF_TRANSPORT',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
      details: {
        designation: 'Admissions & Logistics Incharge',
        employeeId: 'EIS-STF-023',
        phone: '9988776655',
        gender: 'Male'
      }
    }
  ]);

  // Auth state
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loginPhone, setLoginPhone] = useState('9412398765');
  const [loginPassword, setLoginPassword] = useState('98765');
  const [loginRoleKey, setLoginRoleKey] = useState<'student' | 'teacher' | 'admin' | 'staff_transport'>('student');
  const [authError, setAuthError] = useState('');
  
  // Account choice modal/screen states for phone numbers registered to multiple profiles
  const [pendingLoginProfiles, setPendingLoginProfiles] = useState<User[] | null>(null);
  const [siblingProfiles, setSiblingProfiles] = useState<User[]>([]);
  const [showSwitchModal, setShowSwitchModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPasswordInput, setOldPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [passwordChangeError, setPasswordChangeError] = useState('');


  // Portal Roles state
  const [isDarkMode, setIsDarkMode] = useLocalStorage('EIS_isDarkMode', false);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const [currentUser, setCurrentUser] = useState<User>({
    id: 'USR_STUDENT_01',
    name: 'Aarav Kumar',
    email: 'aarav.kumar@eurodharuhera.edu.in',
    role: 'STUDENT',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      class: 'Grade 10-A',
      rollNo: 'EIS-10A-14',
      phone: '9412398765',
      busRoute: 'Route-5B',
      gender: 'Male',
      admissionNo: 'EIS-2024-0482'
    }
  });
  
  // Shared interactive database state (acting as local synchronized state)
  const [circulars, setCirculars] = useLocalStorage<Circular[]>('EIS_circulars', initialCirculars);
  const [homework, setHomework] = useLocalStorage<Homework[]>('EIS_homework', initialHomework);
  const [leaves, setLeaves] = useLocalStorage<LeaveRequest[]>('EIS_leaves', initialLeaves);
  const [invoices, setInvoices] = useLocalStorage<FeeInvoice[]>('EIS_invoices', initialInvoices);
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [busRoute, setBusRoute] = useState<BusRoute>(mockBusRoute);

  // Classes created by Admin
  const [schoolClasses, setSchoolClasses] = useLocalStorage<string[]>('EIS_classes', ['Grade 10-A', 'Grade 8-B', 'Grade 9-C']);

  // Classroom Attendance state for Mrs. Sunita Rao's mentor class (Grade 10-A)
  const [rollCall, setRollCall] = useState<Record<string, 'Present' | 'Absent' | 'Late' | 'Half-Day'>>({
    'Aarav Kumar': 'Present',
    'Diya Sharma': 'Present',
    'Rohan Roy': 'Present',
    'Sneha Gupta': 'Absent',
    'Amit Yadav': 'Present'
  });

  // active menu subsection in dashboard
  const [activeMenu, setActiveMenu] = useState<string>('Overview');

  // Interactive chat inputs
  const [chatInput, setChatInput] = useState('');
  const [chatTargetClass, setChatTargetClass] = useState<string>('');
  const [chatTargetUserId, setChatTargetUserId] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Homework Upload state
  const [selectedHomeWorkId, setSelectedHomeworkId] = useState<string | null>(null);
  const [homeworkUploadName, setHomeworkUploadName] = useState('');

  // Fee payment processing state
  const [selectedInvoiceForPayment, setSelectedInvoiceForPayment] = useState<FeeInvoice | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCVV, setCardCVV] = useState('');
  const [isPayingFee, setIsPayingFee] = useState(false);
  const [paymentCompleted, setPaymentCompleted] = useState(false);

  // Student Apply Leave state
  const [leaveStartDate, setLeaveStartDate] = useState('');
  const [leaveEndDate, setLeaveEndDate] = useState('');
  const [leaveReason, setLeaveReason] = useState('');

  // Teacher Schedule Exam state
  const [examSubject, setExamSubject] = useState('Mathematics');
  const [examDate, setExamDate] = useState('');
  const [examSyllabus, setExamSyllabus] = useState('');
  const [examsList, setExamsList] = useLocalStorage<Exam[]>('EIS_exams', initialExams);
  const [examTargetClass, setExamTargetClass] = useState('Grade 10-A');

  // Teacher post assignment state
  const [newHwSubject, setNewHwSubject] = useState('Mathematics');
  const [newHwTitle, setNewHwTitle] = useState('');
  const [newHwDesc, setNewHwDesc] = useState('');
  const [newHwDueDate, setNewHwDueDate] = useState('');
  const [newHwTargetClass, setNewHwTargetClass] = useState('Grade 10-A');
  const [hwAttachment, setHwAttachment] = useState<File | null>(null);

  // Attachments
  const [studentHwAttachment, setStudentHwAttachment] = useState<File | null>(null);

  // Admin Create Class State
  const [newClassName, setNewClassName] = useState('');
  const [newStudentName, setNewStudentName] = useState('');
  const [newStudentPhone, setNewStudentPhone] = useState('');
  const [newStudentGender, setNewStudentGender] = useState('Male');

  const [newTeacherName, setNewTeacherName] = useState('');
  const [newTeacherPhone, setNewTeacherPhone] = useState('');
  const [newTeacherGender, setNewTeacherGender] = useState('Female');
  const [newTeacherSubject, setNewTeacherSubject] = useState('Mathematics');
  const [newTeacherClass, setNewTeacherClass] = useState('None');

  // Teacher grading inputs state
  const [activeEditingExamId, setActiveEditingExamId] = useState<string | null>(null);
  const [editingStudentMarks, setEditingStudentMarks] = useState<Record<string, string>>({});

  // Dynamic Full Year Attendance
  const [attendanceSelectedMonth, setAttendanceSelectedMonth] = useState('May');
  const [fullYearAttendance, setFullYearAttendance] = useState<Record<string, {date: string, status: string, remarks?: string}[]>>({});
  const [attendanceMarkedToday, setAttendanceMarkedToday] = useState(false);
  const [attendanceAlertShown, setAttendanceAlertShown] = useState(false);

  useEffect(() => {
    if (currentUser.role === 'TEACHER' && !attendanceMarkedToday && !attendanceAlertShown) {
      alert(`[SYSTEM REMINDER] -> Please mark the daily attendance for your mentor class (${currentUser.details?.classTeacherOf || 'Grade 10-A'}). Unmarked past days are updated to NM (Not Marked).`);
      setAttendanceAlertShown(true);
    }
  }, [currentUser, attendanceMarkedToday, attendanceAlertShown]);

  useEffect(() => {
    // Generate a full year's mock attendance for the current user
    const generateYear = () => {
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      const data: any = {};
      const today = new Date().toISOString().split('T')[0];
      months.forEach(m => {
        const daysInMonth = m === 'February' ? 28 : (['April', 'June', 'September', 'November'].includes(m) ? 30 : 31);
        data[m] = Array.from({length: daysInMonth}).map((_, i) => {
          const dateStr = `2026-${String(months.indexOf(m)+1).padStart(2,'0')}-${String(i+1).padStart(2,'0')}`;
          let statusStr = 'NM';
          if (dateStr <= today) {
             statusStr = Math.random() > 0.95 ? 'Absent' : (Math.random() > 0.90 ? 'Late' : 'Present');
             // override today if not marked
             if (dateStr === today && !attendanceMarkedToday) {
                 statusStr = 'NM';
             } else if (dateStr === today && attendanceMarkedToday) {
                 statusStr = 'Present'; // mock marked
             }
          }
          return {
            date: dateStr,
            status: statusStr,
            remarks: Math.random() > 0.95 && statusStr === 'Absent' ? 'Medical note' : null
          };
        });
      });
      return data;
    };
    setFullYearAttendance(generateYear());
  }, [currentUser, attendanceMarkedToday]);

  // Scroll messages to bottom
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeMenu]);

  // Adjust menus appropriately on role hot-switch
  const handleLoginSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!loginPhone) {
      setAuthError('Please enter your registered phone number.');
      return;
    }
    
    const cleanPhone = loginPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 5) {
      setAuthError('Please enter a valid phone number. Standard PIN format is the last 5 digits of your telephone number.');
      return;
    }

    const expectedPin = cleanPhone.slice(-5);
    
    // We match by suffix of normalized number (last 10 digits for full robustness)
    const targetSuffix = cleanPhone.slice(-10);
    const matchingUsersTotal = campusUsers.filter(u => {
      const uPhoneClean = (u.details?.phone || '').replace(/[^0-9]/g, '');
      return uPhoneClean.endsWith(targetSuffix);
    });

    if (matchingUsersTotal.length === 0) {
      setAuthError('Access Denied: No school profile matches this registered phone number.');
      return;
    }

    // Check against individual user passwords or default expected PIN
    const matchingUsers = matchingUsersTotal.filter(u => {
      const uPassword = u.password || expectedPin;
      return loginPassword === uPassword || loginPassword === 'password123';
    });

    if (matchingUsers.length === 0) {
      setAuthError('Verification Denied: Invalid password.');
      return;
    }

    setAuthError('');
    
    // If multiple profiles share this registered number, trigger choices drawer!
    if (matchingUsers.length > 1) {
      setPendingLoginProfiles(matchingUsers);
    } else {
      executeDirectLogin(matchingUsers[0], matchingUsers);
    }
  };

  const executeDirectLogin = (selectedUser: User, listForPhone: User[]) => {
    setCurrentUser(selectedUser);
    setIsLoggedIn(true);
    setPendingLoginProfiles(null);
    setSiblingProfiles(listForPhone);
    setAuthError('');

    // Default menus
    if (selectedUser.role === 'ADMIN') {
      setActiveMenu('Overview');
    } else if (selectedUser.role === 'TEACHER') {
      setActiveMenu('Overview');
    } else if (selectedUser.role === 'STUDENT' || selectedUser.role === 'PARENT') {
      setActiveMenu('Academic Feed');
    } else {
      setActiveMenu('Transport Operations');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setSiblingProfiles([]);
  };

  const handleGenerateIDCard = () => {
    const element = document.getElementById('student-id-card-view');
    if (!element) return;
    
    const originalStyle = element.style.cssText;
    element.style.position = 'fixed';
    element.style.left = '0';
    element.style.top = '0';
    element.style.opacity = '1';
    element.style.zIndex = '-9999';
    element.style.display = 'block';

    html2canvas(element, { scale: 4, useCORS: true }).then((canvas) => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', [54, 86]);
      pdf.addImage(imgData, 'PNG', 0, 0, 54, 86);
      pdf.save(`${currentUser.name}_Digital_ID.pdf`);
      
      element.style.cssText = originalStyle;
    }).catch(err => {
      console.error(err);
      element.style.cssText = originalStyle;
    });
  };

  const handleRoleChange = (roleKey: string) => {
    const matchedProfile = campusUsers.find(u => u.id === roleKey) || campusUsers[0];
    setCurrentUser(matchedProfile);
    
    // Default menus
    if (matchedProfile.role === 'ADMIN') {
      setActiveMenu('Overview');
    } else if (matchedProfile.role === 'TEACHER') {
      setActiveMenu('Overview');
    } else if (matchedProfile.role === 'STUDENT' || matchedProfile.role === 'PARENT') {
      setActiveMenu('Academic Feed');
    } else {
      setActiveMenu('Transport Operations');
    }
  };

  // Add Circular Broadcast from Admin notice board
  const handleAddCircular = (newCirc: Circular) => {
    setCirculars(prev => [newCirc, ...prev]);
  };

  // Student Homework submission trigger
  const handleSubmitHomework = (e: FormEvent) => {
    e.preventDefault();
    if (!selectedHomeWorkId || !homeworkUploadName) return;

    // Mutate state
    setHomework(prev => prev.map((hw) => {
      if (hw.id === selectedHomeWorkId) {
        return {
          ...hw,
          submitted: true,
          submissionsCount: (hw.submissionsCount || 0) + 1
        };
      }
      return hw;
    }));

    let msg = `Successfully submitted the assignment worksheet.`;
    if (studentHwAttachment) {
      msg += `\nYour file "${studentHwAttachment.name}" is attached and stored safely under your Student Registry.`;
      setStudentHwAttachment(null);
    }
    
    setSelectedHomeworkId(null);
    setHomeworkUploadName('');
    alert(msg);
  };

  // Student Leave Apply trigger
  const handleApplyLeave = (e: FormEvent) => {
    e.preventDefault();
    if (!leaveStartDate || !leaveEndDate || !leaveReason) return;

    const newRequest: LeaveRequest = {
      id: `L-${Date.now().toString().slice(-4)}`,
      studentName: 'Aarav Kumar',
      class: 'Grade 10-A',
      startDate: leaveStartDate,
      endDate: leaveEndDate,
      reason: leaveReason,
      status: 'Pending',
      appliedOn: new Date().toISOString().split('T')[0]
    };

    setLeaves(prev => [newRequest, ...prev]);
    
    // Clear state
    setLeaveStartDate('');
    setLeaveEndDate('');
    setLeaveReason('');
    
    // Show checklist
    alert('Leave Application submitted to school database. You can track status on the portal timeline, or hot-swap to the Admin portal to approve it!');
  };

  // Admin/Teacher approves leave request in real-time
  const handleApproveLeave = (leaveId: string, flag: 'Approved' | 'Rejected') => {
    setLeaves(prev => prev.map((lv) => {
      if (lv.id === leaveId) {
        return {
          ...lv,
          status: flag,
          reviewedBy: `${currentUser.name} (${currentUser.role === 'ADMIN' ? 'Managing Director' : 'Specialist'})`
        };
      }
      return lv;
    }));
    if (flag === 'Approved') {
      alert(`Approval submitted successfully! The central school timeline and the daily calendar log for the student have been automatically updated recognizing these marked dates as officially absent.`);
    }
  };

  // Parent fee payment execution simulation
  const handleFeePaymentSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!cardNumber || !cardExpiry || !cardCVV) return;

    setIsPayingFee(true);

    setTimeout(() => {
      setIsPayingFee(false);
      setPaymentCompleted(true);
      
      // Update invoice as paid in interactive state
      setInvoices(prev => prev.map((inv) => {
        if (selectedInvoiceForPayment && inv.id === selectedInvoiceForPayment.id) {
          return {
            ...inv,
            status: 'Paid',
            paidAmount: inv.totalAmount,
            paymentHistory: [
              {
                date: new Date().toISOString().replace('T', ' ').slice(0, 16),
                amount: inv.totalAmount,
                transactionId: `TXN-EIS-${Math.floor(100000000 + Math.random() * 900000000)}`,
                method: 'Secured Card Gate Pay'
              }
            ]
          };
        }
        return inv;
      }));
    }, 2000);
  };

  // Parent/Teacher chat dialogue submitter
  const handleSendChatMessage = (e: FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !chatTargetUserId) return;

    const newMessage: ChatMessage = {
      id: `M-${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      receiverId: chatTargetUserId,
      content: chatInput,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16)
    };

    setMessages(prev => [...prev, newMessage]);
    setChatInput('');
  };

  // Teacher Schedule Exam trigger
  const handleScheduleExamSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!examDate || !examSyllabus) return;

    // Check authorization rules
    const assignedSub = currentUser.details?.assignedSubject || '';
    const classMentorOf = currentUser.details?.classTeacherOf || '';
    const subjectMatches = examSubject.toLowerCase() === assignedSub.toLowerCase();
    const classMentorMatches = examTargetClass === classMentorOf && classMentorOf !== 'None';

    if (currentUser.role === 'TEACHER' && !subjectMatches && !classMentorMatches) {
      alert(`Restricted Workspace Action:\n\nAs a specialist in "${assignedSub}", you are only authorized to schedule exams of other subjects inside your Class Teachership class ("${classMentorOf === 'None' || !classMentorOf ? 'None' : classMentorOf}"). You cannot schedule a "${examSubject}" exam for "${examTargetClass}".`);
      return;
    }

    const newExam: Exam = {
      id: `EX-${Date.now().toString().slice(-2)}`,
      title: newHwTitle || 'Periodic PA-1 Series',
      class: examTargetClass,
      subject: examSubject,
      date: examDate,
      duration: '1.5 Hours',
      syllabus: examSyllabus,
      publishedResults: {}
    };

    setExamsList(prev => [...prev, newExam]);
    setExamDate('');
    setExamSyllabus('');
    setNewHwTitle('');
    
    // Email simulation notification helper
    alert(`Success! Scheduled new ${examSubject} test exam for ${examTargetClass}.\n\n[SYSTEM SMS & EMAIL BOT] -> Automated notification sent to the registered email and phone number for the parents of ${examTargetClass} informing them about the newly scheduled ${examSubject} test exam.`);
  };

  // Teacher Publish Homework assignment
  const handlePublishHomework = (e: FormEvent) => {
    e.preventDefault();
    if (!newHwTitle || !newHwDesc || !newHwDueDate) return;

    // Check authorization rules
    const assignedSub = currentUser.details?.assignedSubject || '';
    const classMentorOf = currentUser.details?.classTeacherOf || '';
    const subjectMatches = newHwSubject.toLowerCase() === assignedSub.toLowerCase();
    const classMentorMatches = newHwTargetClass === classMentorOf && classMentorOf !== 'None';

    if (currentUser.role === 'TEACHER' && !subjectMatches && !classMentorMatches) {
      alert(`Restricted Workspace Action:\n\nAs a specialist in "${assignedSub}", you are only authorized to publish worksheets of other subjects inside your Class Teachership class ("${classMentorOf === 'None' || !classMentorOf ? 'None' : classMentorOf}"). You cannot assign a "${newHwSubject}" worksheet for "${newHwTargetClass}".`);
      return;
    }

    const newHomework: Homework = {
      id: `HW-${Date.now().toString().slice(-2)}`,
      title: newHwTitle,
      subject: newHwSubject,
      classAssigned: newHwTargetClass,
      dueDate: newHwDueDate,
      description: newHwDesc,
      teacherName: currentUser.name,
      submissionsCount: 0,
      submitted: false
    };

    setHomework(prev => [newHomework, ...prev]);
    setNewHwTitle('');
    setNewHwDesc('');
    setNewHwDueDate('');
    
    let msg = `Congratulations! Homework worksheet published successfully to ${newHwTargetClass} students.`;
    if (hwAttachment) {
      msg += `\nAttached file "${hwAttachment.name}" was uploaded along with it.`;
      setHwAttachment(null);
    }
    
    // Email simulation notification helper
    const parentsOfClass = campusUsers.filter(u => u.role === 'PARENT' && u.details?.class === newHwTargetClass);
    msg += `\n\n[SYSTEM SMS & EMAIL BOT] -> Automated notification dispatched to parents of ${newHwTargetClass} concerning the newly available ${newHwSubject} assignment.`;
    
    alert(msg);
  };

  // Toggle roll call options
  const toggleAttendanceRollCall = (student: string, val: 'Present' | 'Absent' | 'Late' | 'Half-Day') => {
    setRollCall(prev => ({ ...prev, [student]: val }));
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#F9FAF7] flex flex-col font-sans text-[#2D3A3A] items-center justify-center p-4 relative">
        {/* MULTIPLE PROFILE CHOICE SELECTOR MODAL */}
        <AnimatePresence>
        {pendingLoginProfiles && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex items-center justify-center z-50 p-4"
          >
            <motion.div 
              initial={{ y: 50, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 20, opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", bounce: 0.3, duration: 0.4 }}
              className="bg-white rounded-3xl border border-[#E0E4D9] shadow-2xl max-w-md w-full p-6 text-center space-y-5"
            >
              <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-700 mx-auto">
                <Users className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">Multiple Workspace Profiles Found</h3>
                <p className="text-xs text-slate-500 mt-1">
                  The telephone <strong className="font-mono text-slate-700">{loginPhone}</strong> is registered for several active school profiles. Select which workspace you want to load:
                </p>
              </div>

              <div className="space-y-3 text-left pt-2">
                {pendingLoginProfiles.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => {
                      executeDirectLogin(p, pendingLoginProfiles);
                    }}
                    className="w-full text-left p-3.5 rounded-2xl border border-slate-100 bg-slate-50/50 hover:border-indigo-500 hover:bg-indigo-50/20 transition-all flex items-center gap-3 cursor-pointer group"
                  >
                    <img
                      src={p.avatar}
                      alt={p.name}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-black text-slate-800 truncate group-hover:text-indigo-600 flex items-center justify-between">
                        <span>{p.name}</span>
                        <span className="text-[10px] ml-2 text-indigo-600 bg-indigo-50 py-0.5 px-1.5 rounded uppercase font-bold tracking-tight">
                          {p.role}
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        {p.role === 'STUDENT' ? `${p.details?.class} Student` : `${p.details?.designation || 'Faculty Specialist'}`}
                      </p>
                      {p.role === 'STUDENT' && (
                        <p className="text-[10px] text-slate-400 font-mono mt-1">
                          Admission No: <strong className="text-slate-600">{p.details?.admissionNo}</strong> | Gender: <span className="text-slate-600">{p.details?.gender}</span>
                        </p>
                      )}
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600" />
                  </button>
                ))}
              </div>

              <button
                onClick={() => setPendingLoginProfiles(null)}
                className="text-xs text-slate-500 hover:text-slate-700 underline font-semibold cursor-pointer"
              >
                Go back to login screen
              </button>
            </motion.div>
          </motion.div>
        )}
        </AnimatePresence>

        <div className="w-full max-w-md bg-white rounded-3xl border border-[#E0E4D9] shadow-md overflow-hidden">
          {/* Header */}
          <div className="bg-slate-900 p-6 text-white text-center relative border-b border-[#E0E4D9]">
            <div className="absolute top-4 left-4">
              <button
                onClick={onExitPortal}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-2 py-1 rounded cursor-pointer animate-pulse"
              >
                <ArrowLeft className="w-3 h-3" /> Exit Homepage
              </button>
            </div>
            <div className="w-24 h-24 mx-auto mb-3 flex items-center justify-center rounded-full shadow-lg animate-bounce hover:animate-none transition-all overflow-hidden bg-white">
              <img src={eisLogo} alt="Euro Group of Schools Logo" className="w-full h-full object-cover mix-blend-multiply" />
            </div>
            <h1 className="font-bold text-lg leading-tight">Euro International School</h1>
            <p className="text-[10px] text-amber-400 uppercase tracking-widest mt-1">Dharuhera • Student & Faculty Portal</p>
          </div>

          {/* Form */}
          <div className="p-6 space-y-5">
            <div className="space-y-1 text-center">
              <h3 className="text-base font-bold text-[#2D3A3A]">Campus Identity Clearance</h3>
              <p className="text-xs text-[#8A9680]">Secure login via your registered school phone number</p>
            </div>

            {authError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Role Select Pills for easy trial filling */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#8A9680] uppercase tracking-wider">Fill Demo Credentials</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { key: 'student_aarav', label: 'Student Aarav', phone: '9412398765' },
                    { key: 'student_ananya', label: 'Student Ananya', phone: '9412398765' },
                    { key: 'teacher_sunita', label: 'Teacher Sunita', phone: '9812345678' },
                    { key: 'admin_rajesh', label: 'Super Admin', phone: '9876543210' },
                    { key: 'transport', label: 'Transport Incharge', phone: '9988776655' }
                  ].map((role) => (
                    <button
                      type="button"
                      key={role.key}
                      onClick={() => {
                        setLoginPhone(role.phone);
                        setLoginPassword(role.phone.slice(-5));
                        setAuthError('');
                      }}
                      className="text-[10px] font-bold py-2 px-3 rounded-xl border border-[#E0E4D9] bg-white text-[#6B7662] hover:bg-slate-50 cursor-pointer text-center"
                    >
                      🧪 Use {role.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Phone Number */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-[#8A9680] uppercase tracking-wider">Registered Phone Number</label>
                <div className="relative">
                  <span className="absolute left-3 top-3.5 text-xs text-slate-400 font-bold font-mono">+91</span>
                  <input
                    type="tel"
                    className="w-full text-xs font-mono border border-[#E0E4D9] rounded-xl p-3.5 pl-11 bg-[#F9FAF7] text-[#2D3A3A] focus:bg-white"
                    placeholder="e.g. 9412398765"
                    value={loginPhone}
                    onChange={e => setLoginPhone(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="block text-xs font-bold text-[#8A9680] uppercase tracking-wider">Access PIN / Password</label>
                  <span className="text-[10px] text-slate-400 font-medium">Auto-PIN: Last 5 Digits of Phone No.</span>
                </div>
                <input
                  type="password"
                  className="w-full text-xs font-mono border border-[#E0E4D9] rounded-xl p-3.5 bg-[#F9FAF7] text-[#2D3A3A] focus:bg-white"
                  placeholder="e.g. Last 5 digits or password123"
                  value={loginPassword}
                  onChange={e => setLoginPassword(e.target.value)}
                  required
                />
              </div>

              {/* Help Text */}
              <div className="text-[10px] text-slate-500 bg-[#F0F2EB] p-3 rounded-xl border border-[#E0E4D9] space-y-1.5">
                <div className="font-bold text-[#2D3A3A] flex items-center gap-1">🔒 Phone Credential Security Active</div>
                <p className="leading-relaxed text-[11px]">
                  All password credentials are mapped directly as the <strong className="text-slate-800">last 5 digits</strong> of the users phone number.
                </p>
                <div className="pt-1.5 border-t border-[#E0E4D9]/60 space-y-1">
                  <div className="font-semibold text-[#5A6F5A]">New Structured Phone Registries:</div>
                  <div className="grid grid-cols-1 gap-1 text-[10px] font-mono break-all text-slate-600">
                    <div>• <b>9412398765</b> maps to BOTH Aarav & Ananya (Sibling Selection mode)</div>
                    <div>• <b>9812345678</b> maps to BOTH Mrs. Rao (Teacher) and Rahul Rao (Student Split)</div>
                    <div>• <b>9876543210</b> maps to Mr. Rajesh (Super Admin)</div>
                  </div>
                  <div className="mt-1 font-semibold text-slate-500">Auto Trial PIN mapping: <span className="font-mono bg-white px-1 text-[#2D3A3A] font-bold">98765</span> for Student, <span className="font-mono bg-white px-1 text-[#2D3A3A] font-bold">45678</span> for Teacher.</div>
                </div>
              </div>

              {/* Action */}
              <button
                type="submit"
                className="w-full bg-[#5A6F5A] hover:bg-[#495E49] text-white font-bold text-xs py-3 rounded-xl transition-all shadow-md shadow-[#5A6F5A]/10 cursor-pointer flex items-center justify-center gap-1.5"
              >
                Clear Identity & Enter Portal
                <ChevronRight className="w-4 h-4 text-white" />
              </button>
            </form>
          </div>
        </div>
        <p className="text-[10px] text-[#8A9680] mt-6 tracking-wide uppercase font-bold">&copy; Euro International School Council &bull; Secured DB System</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      
      {/* FULL PREVIEW TOP FLOATING SIMULATOR BAR */}
      <div className="bg-slate-900 border-b-2 border-amber-400 py-3 px-4 shadow-lg text-slate-100 sticky top-0 z-50 print:hidden">
        {/* SWITCH MODAL FOR POPUP MODE */}
        {showSwitchModal && (
          <div className="fixed inset-0 bg-slate-900/85 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-white text-[#2D3A3A] rounded-3xl border border-[#E0E4D9] shadow-2xl max-w-md w-full p-6 text-center space-y-5">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-600 mx-auto">
                <Users className="h-6 w-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">Dynamic Active Switchboard</h3>
                <p className="text-xs text-slate-500 mt-1">
                  These matching workspace profiles are registered on this shared device phone line. Click any to hot-reload:
                </p>
              </div>

              <div className="space-y-2.5 text-left pt-2">
                {siblingProfiles.map((p) => {
                  const isActive = p.id === currentUser.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => {
                        setCurrentUser(p);
                        setShowSwitchModal(false);
                      }}
                      className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-center gap-3 cursor-pointer ${
                        isActive
                          ? 'border-indigo-500 bg-indigo-50/40 text-slate-900 ring-2 ring-indigo-500/20'
                          : 'border-slate-100 bg-slate-50 hover:border-indigo-400 hover:bg-indigo-50/15'
                      }`}
                    >
                      <img
                        src={p.avatar}
                        alt={p.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-black text-slate-800 truncate flex items-center justify-between">
                          <span>{p.name} {isActive && <span className="text-emerald-600 text-[10px] font-bold">● ACTIVE NOW</span>}</span>
                          <span className="text-[9px] bg-slate-200 text-slate-700 font-bold px-1 py-0.5 rounded tracking-wide font-mono">
                            {p.role}
                          </span>
                        </h4>
                        <p className="text-[11px] text-slate-400">
                          {p.role === 'STUDENT' ? `${p.details?.class} Student` : `${p.details?.designation || 'Specialist'}`}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setShowSwitchModal(false)}
                className="text-xs text-slate-400 hover:text-slate-600 font-semibold cursor-pointer block mx-auto pt-2"
              >
                Close and continue
              </button>
            </div>
          </div>
        )}

        {showPasswordModal && (
          <AnimatePresence>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-900/85 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            >
              <motion.div 
                initial={{ y: 50, opacity: 0, scale: 0.95 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                exit={{ y: 20, opacity: 0, scale: 0.95 }}
                transition={{ type: "spring", bounce: 0.3, duration: 0.4 }}
                className="bg-white text-[#2D3A3A] rounded-3xl border border-[#E0E4D9] shadow-2xl max-w-sm w-full p-6 text-center space-y-4"
              >
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 mx-auto">
                  <Shield className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">Change Account Password</h3>
                  <p className="text-[10px] text-slate-500 mt-1">Update your personal login password for {currentUser.name}</p>
                </div>
                
                <form onSubmit={(e) => {
                  e.preventDefault();
                  
                  // Verify old password
                  const currentPhone = (currentUser.details?.phone || '').replace(/[^0-9]/g, '');
                  const expectedPin = currentPhone.slice(-5);
                  const validOldPass = currentUser.password || expectedPin;
                  
                  if (oldPasswordInput !== validOldPass && oldPasswordInput !== 'password123') {
                     setPasswordChangeError('Old password does not match.');
                     return;
                  }
                  
                  if (newPasswordInput.length < 5) {
                     setPasswordChangeError('New password must be at least 5 characters.');
                     return;
                  }

                  // Actually change it across users DB
                  setCampusUsers(prev => prev.map(u => 
                    u.id === currentUser.id ? { ...u, password: newPasswordInput } : u
                  ));
                  setCurrentUser(prev => ({ ...prev, password: newPasswordInput }));

                  alert('Password successfully changed for ' + currentUser.name + '.');
                  setShowPasswordModal(false);
                }} className="space-y-4 text-left">
                  {passwordChangeError && (
                    <div className="bg-rose-50 border-l-2 border-rose-600 p-2 text-[10px] text-rose-800 font-semibold mb-2">
                      ⚠️ {passwordChangeError}
                    </div>
                  )}
                  
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Old Password</label>
                    <input
                      required
                      type="password"
                      className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 rounded-lg p-2.5 outline-none transition-colors"
                      value={oldPasswordInput}
                      onChange={e => setOldPasswordInput(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">New Password</label>
                    <input
                      required
                      type="password"
                      className="w-full text-xs font-mono font-bold bg-slate-50 border border-slate-200 focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 rounded-lg p-2.5 outline-none transition-colors"
                      value={newPasswordInput}
                      onChange={e => setNewPasswordInput(e.target.value)}
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs py-2.5 rounded-lg cursor-pointer transition-colors"
                  >
                    Confirm Change
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowPasswordModal(false)}
                    className="w-full text-xs text-slate-500 hover:text-slate-800 font-semibold cursor-pointer block"
                  >
                    Cancel
                  </button>
                </form>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        )}

        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <img src={eisLogo} alt="EIS Logo" className="h-8 w-8 object-cover rounded-md shadow-sm mix-blend-multiply bg-white" />
            <span className="text-xs font-bold text-slate-400 hidden sm:inline-block">Secured Active Session:</span>
            <span className="text-xs font-bold text-white flex items-center gap-2">
              <img src={currentUser.avatar} className="w-5 h-5 rounded-full object-cover inline-block" alt="" referrerPolicy="no-referrer" />
              <span className="text-amber-400 font-semibold">{currentUser.name}</span>
              <span className="text-[10px] bg-slate-800 border border-slate-700 text-slate-300 px-1.5 py-0.5 rounded font-mono">
                {currentUser.role}
              </span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* The demanded Red switch account button triggers only when phone contains siblings */}
            {siblingProfiles.length > 1 && (
              <button
                onClick={() => setShowSwitchModal(true)}
                className="bg-red-600 hover:bg-red-700 text-white font-bold text-xs py-1.5 px-3 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-md shadow-red-900/20 active:scale-95 transition-all text-center animate-pulse"
              >
                <Users className="w-3.5 h-3.5" />
                Switch Account
              </button>
            )}

            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="text-xs text-amber-300 hover:text-amber-100 font-bold flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
              {isDarkMode ? 'Light Theme' : 'Dark Mode'}
            </button>

            <button
              onClick={() => {
                setShowPasswordModal(true);
                setOldPasswordInput('');
                setNewPasswordInput('');
                setPasswordChangeError('');
              }}
              className="text-xs text-indigo-300 hover:text-indigo-100 font-bold flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
            >
              🔒 Change Password
            </button>

            <button
              onClick={handleLogout}
              className="text-xs text-rose-300 hover:text-rose-100 font-bold flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
            >
              🚪 Sign Out
            </button>
            <button
              onClick={onExitPortal}
              className="text-xs text-slate-300 hover:text-white font-semibold flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 rounded-lg border border-slate-700 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> School Homepage
            </button>
          </div>
        </div>
      </div>

      {/* PORTAL MAIN CONTENT CANVAS CONTAINER */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* SIDE BAR / METRICS DETAILS */}
        <div className="lg:col-span-1 space-y-6 print:hidden">
          {/* USER CONSOLE PROFILE DETAIL */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 text-center flex flex-col items-center">
            <div className="h-16 w-16 rounded-full overflow-hidden mb-3 border-2 border-indigo-500/10 shadow-sm">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120&q=80'}
                alt={currentUser.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <h3 className="text-sm font-bold text-slate-800">{currentUser.name}</h3>
            <span className="text-[10px] text-indigo-600 bg-indigo-50 font-bold px-2 py-0.5 rounded mt-1">
              {currentUser.role === 'STAFF_TRANSPORT' ? 'TRANSPORT OPERATIONS' : currentUser.role}
            </span>
            <p className="text-[10px] font-mono text-slate-400 mt-2">{currentUser.email}</p>

            <div className="w-full border-t border-slate-100 pt-4 mt-4 text-left space-y-2 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Employee/Roll ID</span>
                <span className="font-mono text-slate-800 font-semibold">{currentUser.details?.employeeId || currentUser.details?.rollNo || 'EIS-PR-1882'}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Category Class</span>
                <span className="text-slate-800 font-semibold">{currentUser.details?.class || 'N/A'}</span>
              </div>
              {currentUser.details?.phone && (
                <div className="flex justify-between text-slate-500">
                  <span>Contact Phone</span>
                  <span className="text-slate-800 font-semibold font-mono">{currentUser.details.phone}</span>
                </div>
              )}
              {currentUser.details?.gender && (
                <div className="flex justify-between text-slate-500">
                  <span>Gender</span>
                  <span className="text-slate-800 font-semibold uppercase">{currentUser.details.gender}</span>
                </div>
              )}
              {currentUser.details?.admissionNo && (
                <div className="flex justify-between text-slate-500">
                  <span>Admission No.</span>
                  <span className="text-slate-800 font-semibold font-mono bg-slate-50 px-1">{currentUser.details.admissionNo}</span>
                </div>
              )}
              {currentUser.role === 'TEACHER' && (
                <>
                  <div className="flex justify-between text-slate-500">
                    <span>Assigned Subject</span>
                    <span className="text-rose-600 font-extrabold">{currentUser.details?.assignedSubject || 'None'}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Class Teacher Of</span>
                    <span className="text-emerald-700 font-extrabold">{currentUser.details?.classTeacherOf || 'None'}</span>
                  </div>
                </>
              )}
            </div>

            {currentUser.role === 'STUDENT' && (
              <button
                onClick={handleGenerateIDCard}
                className="mt-4 w-full bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs py-2 rounded-xl transition-all border border-indigo-100 cursor-pointer flex items-center justify-center gap-1.5"
              >
                🖨️ Generate Digital ID
              </button>
            )}

            <button
              onClick={handleLogout}
              className="mt-4 w-full bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs py-2 rounded-xl transition-all border border-rose-100 cursor-pointer flex items-center justify-center gap-1.5"
            >
              🚪 Sign Out
            </button>
          </div>

          {/* DYNAMIC SIDEBAR MENU LIST based on selected role */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden text-left">
            <div className="p-4 bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-widest">
              Navigation Modules
            </div>
            <div className="divide-y divide-slate-100">
              
              {/* PARENT / STUDENT MENUS */}
              {(currentUser.role === 'PARENT' || currentUser.role === 'STUDENT') && [
                { id: 'Academic Feed', label: '📚 Academics & Tasks', icon: BookOpen },
                { id: 'View Marks & Analytics', label: '📊 View Marks & Analytics', icon: Award },
                { id: 'Academic Calendar', label: '📅 Academic Calendar', icon: CalendarDays },
                { id: 'Attendance Register', label: '📅 Monthly Attendance', icon: Calendar },
                { id: 'Fee & Financials', label: '💳 Pay Online Fees', icon: DollarSign },
                { id: 'Notice Segment', label: '📣 Digital Notice Board', icon: Megaphone },
                { id: 'Interactive GPS Tracker', label: '🚌 School Bus GPS Tracker', icon: Navigation },
                { id: 'Apply Leave Section', label: '💌 Ask Leave Permission', icon: FileText },
                { id: 'Student-Teacher Messages', label: '💬 Student-Educator Chat', icon: Send }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full text-left px-4 py-3 text-xs font-semibold flex items-center gap-2.5 transition-colors cursor-pointer ${
                    activeMenu === item.id 
                      ? 'bg-indigo-50 text-indigo-700 border-l-4 border-indigo-600' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className={`h-4 w-4 ${activeMenu === item.id ? 'text-indigo-600' : 'text-slate-400'}`} />
                  {item.label}
                </button>
              ))}

              {/* TEACHER MENUS */}
              {currentUser.role === 'TEACHER' && [
                { id: 'Overview', label: '🏠 Teacher Dashboard', icon: Layout },
                { id: 'Academic Calendar', label: '📅 Academic Calendar', icon: CalendarDays },
                { id: 'Attendance Register', label: '📅 Monthly Attendance', icon: Calendar },
                { id: 'Mark Attendance Roll', label: '📅 Active Roll Call Marking', icon: UserCheck },
                { id: 'Publish School Homework', label: '📝 Upload Grade Assignments', icon: FileText },
                { id: 'Schedule Examination Desk', label: '🎓 Tests & Syllabuses', icon: CheckSquare },
                { id: 'Grade Student Marks', label: '✍️ Enter & Update Marks', icon: CheckSquare },
                { id: 'Notice Segment', label: '📣 School Circulars board', icon: Megaphone },
                { id: 'Apply Leave Section', label: '💌 Ask Leave Permission', icon: FileText },
                { id: 'Review Leave Petitions', label: '💌 Review Pupil Leaves', icon: FileText },
                { id: 'Student-Teacher Messages', label: '💬 Message Student Chats', icon: Send }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full text-left px-4 py-3 text-xs font-semibold flex items-center gap-2.5 transition-colors cursor-pointer ${
                    activeMenu === item.id 
                      ? 'bg-indigo-50 text-indigo-700 border-l-4 border-indigo-600' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className="h-4 w-4 text-indigo-600" />
                  {item.label}
                </button>
              ))}

              {/* SUPER ADMIN MENUS */}
              {currentUser.role === 'ADMIN' && [
                { id: 'Overview', label: '🏛️ Campus Analytics Summary', icon: Layout },
                { id: 'Academic Calendar', label: '📅 Academic Calendar', icon: CalendarDays },
                { id: 'Manage Academic Faculty', label: '🎓 Manage Academic Faculty', icon: Users },
                { id: 'Manage Class Structure', label: '📚 Create Classes & Exams', icon: Layers },
                { id: 'Broadcast Core Notices', label: '📣 Broadcast Core Notices', icon: Megaphone },
                { id: 'Review Leave Petitions', label: '💌 Review Leave Petitions', icon: FileText },
                { id: 'Manage Transport Routes', label: '🚌 Route Stop Management', icon: Navigation },
                { id: 'Interactive GPS Tracker', label: '🚌 School Bus GPS Tracker', icon: Navigation },
                { id: 'Collect Fee Reports', label: '💳 Global Invoice Clearances', icon: DollarSign }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full text-left px-4 py-3 text-xs font-semibold flex items-center gap-2.5 transition-colors cursor-pointer ${
                    activeMenu === item.id 
                      ? 'bg-indigo-50 text-indigo-700 border-l-4 border-indigo-600' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className="h-4 w-4 text-indigo-600" />
                  {item.label}
                </button>
              ))}

              {/* STAFF/TRANSPORT MENUS */}
              {currentUser.role === 'STAFF_TRANSPORT' && [
                { id: 'Transport Operations', label: '🚌 Transport Dispatches', icon: Navigation },
                { id: 'Academic Calendar', label: '📅 Academic Calendar', icon: CalendarDays },
                { id: 'Account Fee Tracking', label: '💰 Accounting & Invoices', icon: DollarSign },
                { id: 'School Circulars board', label: '📣 Global Notice Boards', icon: Megaphone }
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveMenu(item.id)}
                  className={`w-full text-left px-4 py-3 text-xs font-semibold flex items-center gap-2.5 transition-colors cursor-pointer ${
                    activeMenu === item.id 
                      ? 'bg-indigo-50 text-indigo-700 border-l-4 border-indigo-600' 
                      : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <item.icon className="h-4 w-4 text-indigo-600" />
                  {item.label}
                </button>
              ))}

            </div>
          </div>
        </div>

        {/* WORKSPACE DISPLAY CANVAS */}
        <div className="lg:col-span-3 space-y-6 print:col-span-4 max-w-full">

          {currentUser.role === 'TEACHER' && !attendanceMarkedToday && (
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-start sm:items-center justify-between gap-4 shadow-sm print:hidden">
              <div className="flex items-center gap-3">
                <div className="bg-rose-100 p-2 rounded-full text-rose-600">
                  <AlertCircle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-rose-800 tracking-tight">Daily Attendance Pending</h4>
                  <p className="text-[11px] text-rose-600 mt-0.5 font-medium">Please mark attendance for your mentor class ({currentUser.details?.classTeacherOf || 'Grade 10-A'}) for today.</p>
                </div>
              </div>
              <button 
                onClick={() => setActiveMenu('Mark Attendance Roll')}
                className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-[10px] px-4 py-2 rounded-lg cursor-pointer uppercase tracking-wider transition-colors whitespace-nowrap"
              >
                Mark Now
              </button>
            </div>
          )}

          <AnimatePresence mode="wait">
            <motion.div
              key={activeMenu}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
              {/* ======================================= */}
              {/* PARENT / STUDENT HOOKED DISPLAY BOARDS */}
              {/* ======================================= */}

              {activeMenu === 'Academic Feed' && (
            <div className="space-y-6 text-left">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                <h4 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <BookOpen className="text-indigo-500 h-5 w-5" /> Assigned Homework Tasks (Grade 10-A)
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {homework.map((hw) => {
                    const submissionDeadlinePassed = new Date(hw.dueDate) < new Date();
                    return (
                      <div key={hw.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50 hover:border-slate-200 transition-colors flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-xs bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded">
                              {hw.subject}
                            </span>
                            <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                              hw.submitted 
                                ? 'bg-emerald-100 text-emerald-800 font-bold' 
                                : submissionDeadlinePassed ? 'bg-rose-100 text-rose-800 font-bold' : 'bg-slate-200 text-slate-600'
                            }`}>
                              {hw.submitted ? '✓ Submitted' : submissionDeadlinePassed ? 'Overdue' : 'Pending Action'}
                            </span>
                          </div>
                          
                          <h5 className="font-bold text-slate-800 text-sm leading-tight">{hw.title}</h5>
                          <p className="text-xs text-slate-500 line-clamp-3 leading-relaxed">{hw.description}</p>
                          <div className="text-[10px] text-slate-400 font-mono">mentor: Mrs. Sunita Rao | Due: {hw.dueDate}</div>
                        </div>

                        {!hw.submitted && (
                          <button
                            onClick={() => setSelectedHomeworkId(hw.id)}
                            className="mt-3 w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2 rounded-lg transition-colors cursor-pointer"
                          >
                            Submit Homework Upload
                          </button>
                        )}
                        {hw.submitted && (
                          <div className="mt-3 p-2 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 text-[10px] font-bold text-center">
                            File: EIS_Math_10A_Aarav.pdf processed securely.
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* TIMETABLE & SESSIONS SCHEDULER */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                <h4 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                  <Calendar className="text-emerald-500 h-5 w-5" /> Interactive Daily Timetable (Aarav Kumar)
                </h4>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600 border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50">
                        <th className="p-3 font-bold text-slate-500">Day</th>
                        <th className="p-3 font-bold text-slate-500">Session 1 (8:30)</th>
                        <th className="p-3 font-bold text-slate-500">Session 2 (9:15)</th>
                        <th className="p-3 font-bold text-slate-500">Session 3 (10:00)</th>
                        <th className="p-3 font-bold text-slate-500">Session 4 (11:15)</th>
                        <th className="p-3 font-bold text-slate-500">Session 5 (12:00)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-sans">
                      {mockTimetablesByClass['Grade 10-A'].map((dayObj) => (
                        <tr key={dayObj.day} className="hover:bg-slate-50 transition-colors">
                          <td className="p-3 font-bold text-slate-800 bg-slate-50">{dayObj.day}</td>
                          {dayObj.periods.map((period, pIdx) => (
                            <td key={pIdx} className="p-3 text-slate-700">
                              <div className="font-bold">{period.subject}</div>
                              <div className="text-[10px] text-slate-400 mt-0.5">{period.teacher}</div>
                              {period.isLive && (
                                <a
                                  href={period.meetingUrl}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="mt-1 px-1.5 py-0.5 bg-rose-100 text-rose-700 rounded text-[9px] font-bold flex items-center justify-center gap-1 animate-pulse"
                                >
                                  🔴 Join Live Class
                                </a>
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ATTENDANCE SECTION */}
          {activeMenu === 'View Marks & Analytics' && (
            <div className="space-y-6 text-left font-sans">
              <div id="result-sheet-content" className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                <div>
                  <h4 className="text-xl font-extrabold text-slate-800 tracking-tight flex items-center gap-2">
                    <Award className="text-indigo-600 h-6 w-6" /> Academic Performance Analytics
                  </h4>
                  <div className="flex justify-between items-center mt-1">
                    <p className="text-xs text-slate-500">Review your test scores and compare classroom distributions.</p>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => window.print()}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-lg cursor-pointer print:hidden transition-colors"
                      >
                        🖨️ Print Result Sheet
                      </button>
                      <button 
                        onClick={() => {
                          const element = document.getElementById('result-sheet-content');
                          if (element) {
                              const originalStyles = {
                                padding: element.style.padding,
                                border: element.style.border,
                                borderRadius: element.style.borderRadius,
                                boxShadow: element.style.boxShadow,
                              };
                              // Temporarily remove styles that might mess up PDF canvas
                              element.style.boxShadow = 'none';

                              html2canvas(element, { scale: 2 }).then((canvas) => {
                                  const imgData = canvas.toDataURL('image/png');
                                  const pdf = new jsPDF('p', 'mm', 'a4');
                                  const pdfWidth = pdf.internal.pageSize.getWidth();
                                  const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
                                  pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
                                  pdf.save(`${currentUser.name}_Marksheet.pdf`);

                                  // Restore styles
                                  Object.assign(element.style, originalStyles);
                              });
                          }
                        }}
                        className="bg-[#1e293b] hover:bg-[#0f172a] text-white font-bold text-xs px-4 py-2 rounded-lg cursor-pointer print:hidden transition-colors"
                      >
                        📄 Download PDF
                      </button>
                    </div>
                  </div>
                </div>
                
                {(() => {
                  const studentExams = examsList.filter(ex => ex.class === currentUser.details?.class);
                  
                  if (studentExams.length === 0) {
                     return (
                       <div className="text-center p-8 bg-slate-50 border border-slate-100 rounded-xl">
                          <p className="text-sm font-semibold text-slate-500">No examination results published yet for your class.</p>
                       </div>
                     );
                  }

                  const graphData = studentExams.map(ex => {
                    const marksArr = Object.values(ex.publishedResults || {}).map((v) => parseFloat(String(v).replace('%', '')));
                    const avg = marksArr.length ? marksArr.reduce((a,b) => a+b, 0) / marksArr.length : 0;
                    const max = marksArr.length ? Math.max(...marksArr) : 0;
                    const studentMarkStr = ex.publishedResults?.[currentUser.name] || '0%';
                    const studentMark = parseFloat(String(studentMarkStr).replace('%', '')) || 0;

                    return {
                      name: String(ex.title).replace('Term Exam', '').trim() || ex.subject,
                      subject: ex.subject,
                      Student: studentMark,
                      Average: Math.round(avg * 10) / 10,
                      Highest: max
                    }
                  });

                  return (
                    <div className="space-y-8">
                       <div className="h-72 w-full bg-slate-50 p-4 rounded-xl border border-slate-100">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={graphData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} dy={10} />
                              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} dx={-10} domain={[0, 100]} />
                              <Tooltip 
                                 cursor={{ fill: '#f1f5f9' }}
                                 contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
                                 itemStyle={{ padding: '2px 0' }}
                              />
                              <Legend iconType="circle" wrapperStyle={{ fontSize: '11px', fontWeight: 600, paddingTop: '15px' }} />
                              <Bar dataKey="Student" fill="#4f46e5" radius={[4, 4, 0, 0]} barSize={30} />
                              <Bar dataKey="Average" fill="#94a3b8" radius={[4, 4, 0, 0]} barSize={20} />
                              <Bar dataKey="Highest" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />
                            </BarChart>
                          </ResponsiveContainer>
                       </div>

                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {studentExams.map(ex => {
                             const studentMarkStr = ex.publishedResults?.[currentUser.name] || 'N/A';
                             return (
                               <div key={ex.id} className="p-4 border border-slate-100/80 bg-white rounded-2xl shadow-sm flex items-center justify-between">
                                  <div>
                                    <div className="flex items-center gap-2 mb-1">
                                      <span className="text-[9px] font-black uppercase tracking-wider bg-slate-100 text-slate-500 px-2 py-0.5 rounded">
                                        {ex.subject}
                                      </span>
                                      <span className="text-[10px] text-slate-400 font-mono dot-before">{ex.date}</span>
                                    </div>
                                    <h5 className="font-bold text-slate-800 text-sm leading-tight">{ex.title}</h5>
                                  </div>
                                  <div className="text-right">
                                     <div className="text-xl font-black text-indigo-600">{studentMarkStr}</div>
                                     <div className="text-[9px] font-bold text-slate-400 uppercase tracking-wider mt-0.5">Scored</div>
                                  </div>
                               </div>
                             );
                          })}
                       </div>
                    </div>
                  );
                })()}

              </div>
            </div>
          )}

          {activeMenu === 'Academic Calendar' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-6 font-sans">
              <div className="pb-4 border-b border-slate-150 flex items-center justify-between">
                <div>
                  <h4 className="text-xl font-extrabold text-slate-800 flex items-center gap-2">
                    <CalendarDays className="text-indigo-600 h-6 w-6" /> Academic Calendar
                  </h4>
                  <p className="text-xs text-slate-500 mt-1">Upcoming events, exams, and holidays for the term.</p>
                </div>
              </div>

              <div className="space-y-6">
                {/* UPCOMING EXAMS SECTION */}
                <div>
                  <h5 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
                    <CheckSquare className="text-emerald-500 h-4 w-4" /> Scheduled Exams
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {examsList.length > 0 ? (
                      examsList.map((exam) => (
                        <div key={exam.id} className="p-4 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden">
                           <div className="absolute top-0 left-0 w-1 h-full bg-emerald-500"></div>
                           <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{exam.date}</div>
                           <div className="text-sm font-bold text-slate-800">{exam.title}</div>
                           <div className="text-xs text-slate-500 mt-1">{exam.subject} | {exam.class}</div>
                           <div className="mt-3 text-[10px] bg-white border border-slate-200 px-2 py-1 rounded text-slate-500 inline-block font-medium">
                             {exam.duration}
                           </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-slate-400 italic col-span-3 p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">No exams scheduled currently.</p>
                    )}
                  </div>
                </div>

                {/* PARENT TEACHER MEETINGS */}
                <div>
                  <h5 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
                    <Users className="text-blue-500 h-4 w-4" /> Parent-Teacher Meetings
                  </h5>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden">
                       <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
                       <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">July 15, 2026</div>
                       <div className="text-sm font-bold text-slate-800">Mid-Term Academic Review</div>
                       <div className="text-xs text-slate-500 mt-1">All Grades • Main Hall • 09:00 AM - 02:00 PM</div>
                    </div>
                    <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl relative overflow-hidden">
                       <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
                       <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">November 20, 2026</div>
                       <div className="text-sm font-bold text-slate-800">Term Final Results PTM</div>
                       <div className="text-xs text-slate-500 mt-1">All Grades • Classrooms • 10:00 AM - 01:00 PM</div>
                    </div>
                  </div>
                </div>

                {/* SCHOOL HOLIDAYS */}
                <div>
                  <h5 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2">
                    <Sparkles className="text-amber-500 h-4 w-4" /> School Holidays
                  </h5>
                  <div className="space-y-3">
                    {[
                      { name: 'Summer Break', date: 'June 1 - June 30, 2026', type: 'Term Holiday' },
                      { name: 'Independence Day', date: 'August 15, 2026', type: 'National Holiday' },
                      { name: 'Diwali Break', date: 'October 22 - October 26, 2026', type: 'Festival Holiday' },
                      { name: 'Winter Break', date: 'December 25, 2026 - January 2, 2027', type: 'Term Holiday' }
                    ].map((holiday, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-white border border-slate-200 rounded-lg hover:border-amber-200 transition-colors">
                        <div>
                          <div className="text-sm font-bold text-slate-800">{holiday.name}</div>
                          <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">{holiday.type}</div>
                        </div>
                        <div className="text-xs font-mono font-medium text-slate-600 bg-slate-50 px-3 py-1.5 rounded-md border border-slate-100">
                          {holiday.date}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeMenu === 'Attendance Register' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-6 font-sans">
              <div className="flex justify-between items-center pb-4 border-b border-slate-150">
                <div>
                  <h4 className="text-base font-black text-slate-800">
                    {currentUser.role === 'STUDENT' ? 'Student Attendance Timeline' : 'Staff Attendance Timeline'}
                  </h4>
                  <p className="text-xs text-slate-500">Detailed track history for {currentUser.name} (Year: 2026)</p>
                </div>
                <div className="text-right flex items-center gap-4">
                  <div>
                    <select
                      className="text-xs border border-slate-200 rounded p-1.5 bg-white font-bold text-slate-700"
                      value={attendanceSelectedMonth}
                      onChange={(e) => setAttendanceSelectedMonth(e.target.value)}
                    >
                      <option value="January">January</option>
                      <option value="February">February</option>
                      <option value="March">March</option>
                      <option value="April">April</option>
                      <option value="May">May</option>
                      <option value="June">June</option>
                      <option value="July">July</option>
                      <option value="August">August</option>
                      <option value="September">September</option>
                      <option value="October">October</option>
                      <option value="November">November</option>
                      <option value="December">December</option>
                    </select>
                  </div>
                  <div>
                    <div className="text-2xl font-black text-emerald-600 font-mono">95%</div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Overall</div>
                  </div>
                </div>
              </div>

              {/* Dynamic Calendar Representation */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h5 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Daily Calendar Log: {attendanceSelectedMonth}</h5>
                  <div className="flex gap-2 text-[9px] font-bold text-slate-500">
                    <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-400"></div> Present</span>
                    <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-rose-400"></div> Absent</span>
                    <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-amber-400"></div> Late</span>
                  </div>
                </div>
                <div className="grid grid-cols-5 sm:grid-cols-7 gap-2">
                  {fullYearAttendance[attendanceSelectedMonth]?.map((att: any, index: number) => {
                    const isPresent = att.status === 'Present';
                    const isAbsent = att.status === 'Absent';
                    const isLate = att.status === 'Late';
                    const isNM = att.status === 'NM';
                    
                    return (
                      <div 
                        key={index}
                        className={`p-2 rounded-lg border flex flex-col items-center justify-between min-h-[50px] transition-all hover:bg-slate-50 cursor-help ${
                          isPresent 
                            ? 'bg-emerald-50/50 border-emerald-100/60' 
                            : isAbsent ? 'bg-rose-50 border-rose-100' : isLate ? 'bg-amber-50 border-amber-100' : 'bg-slate-50 border-slate-200'
                        }`}
                        title={att.remarks || (isNM ? 'Not Marked' : 'On check')}
                      >
                        <span className="text-[9px] font-mono text-slate-400 font-semibold">{att.date.slice(-2)}</span>
                        <span className={`text-[10px] font-black ${
                          isPresent ? 'text-emerald-700' : isAbsent ? 'text-rose-700' : isLate ? 'text-amber-700' : 'text-slate-400'
                        }`}>
                          {isPresent ? 'P' : isAbsent ? 'A' : isLate ? 'L' : 'NM'}
                        </span>
                        {att.remarks && <span className="text-[7px] text-slate-400 font-mono truncate max-w-full text-center">💬 note</span>}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* FEES AND FINANCIALS */}
          {activeMenu === 'Fee & Financials' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-6">
              <h4 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                <DollarSign className="text-emerald-600 h-5 w-5" /> Secured Fee Clearance Gateway
              </h4>

              <div className="space-y-4 font-sans">
                {invoices.map((inv) => (
                  <div key={inv.id} className="p-5 rounded-2xl border border-slate-100 bg-slate-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded ${
                          inv.status === 'Paid' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : 'bg-rose-100 text-rose-800 animate-pulse'
                        }`}>
                          {inv.status}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">Invoice: {inv.id}</span>
                      </div>
                      <h5 className="font-bold text-slate-800 text-sm">{inv.term}</h5>
                      <p className="text-xs text-slate-400">Issued On: {inv.issueDate} | Limit Due: {inv.dueDate}</p>
                    </div>

                    <div className="text-right w-full md:w-auto flex flex-col items-end gap-1">
                      <div className="text-lg font-black text-slate-800">₹{inv.totalAmount.toLocaleString('en-IN')}</div>
                      {inv.status === 'Paid' ? (
                        <div className="text-xs text-emerald-600 font-semibold flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded">
                          <CheckCircle className="w-3.5 h-3.5" /> Receipt Download Available
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setSelectedInvoiceForPayment(inv);
                            setPaymentCompleted(false);
                          }}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs px-4 py-2 rounded-lg transition-all cursor-pointer shadow-md shadow-indigo-600/10"
                        >
                          Clear Fees Online
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Transaction history logs */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <h5 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Active Transaction Audit Logs</h5>
                <div className="divide-y divide-slate-100 text-xs">
                  {invoices.filter(inv => inv.status === 'Paid').flatMap(inv => inv.paymentHistory || []).map((pay, pIdx) => (
                    <div key={pIdx} className="py-2.5 flex justify-between">
                      <div>
                        <div className="font-bold text-slate-800">Clearance transaction processing</div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">{pay.transactionId} | Method: {pay.method}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-slate-800">₹{pay.amount.toLocaleString('en-IN')}</div>
                        <div className="text-[10px] text-emerald-600 font-bold">{pay.date}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* NOTICE SEGMENT */}
          {activeMenu === 'Notice Segment' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <NoticeBoard circulars={circulars} />
            </div>
          )}

          {/* GPS TRACKER */}
          {activeMenu === 'Interactive GPS Tracker' && (
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left">
                <h3 className="text-lg font-bold text-slate-800 mb-1">Live Bus Position Monitoring</h3>
                <p className="text-xs text-slate-500 mb-6">Realtime telemetry feeds for Route-5B (Sector-6 Lines) towards EIS Dharuhera Campus</p>
                <TransportMap route={busRoute} currentUser={currentUser} />
              </div>
            </div>
          )}

          {/* LEAVE SECTION */}
          {activeMenu === 'Apply Leave Section' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
              {/* Apply Form */}
              <div className="md:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wide">
                  Draft Student Leave Petition
                </h4>
                
                <form onSubmit={handleApplyLeave} className="space-y-4 font-sans">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Leave Start Date</label>
                      <input
                        type="date"
                        className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                        required
                        value={leaveStartDate}
                        onChange={e => setLeaveStartDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Leave End Date</label>
                      <input
                        type="date"
                        className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                        required
                        value={leaveEndDate}
                        onChange={e => setLeaveEndDate(e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Compelling Reason for Absence</label>
                    <textarea
                      placeholder="Please clarify details of health status, family ceremonies or other urgent reasons to mentor faculty..."
                      className="w-full text-sm border border-slate-200 rounded-lg p-2.5 h-24 bg-white"
                      required
                      value={leaveReason}
                      onChange={e => setLeaveReason(e.target.value)}
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2 px-5 rounded-lg transition-colors cursor-pointer"
                  >
                    Broadcast Petition to Mentor & Admin
                  </button>
                </form>
              </div>

              {/* Status Tracking Timeline */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wide">
                  History Timeline
                </h4>
                <div className="space-y-4 font-sans text-xs">
                  {leaves.map((lv) => (
                    <div key={lv.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 relative space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="font-mono text-[9px] text-slate-400">ID: {lv.id}</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          lv.status === 'Approved' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : lv.status === 'Rejected' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {lv.status}
                        </span>
                      </div>
                      <div className="font-bold text-slate-800">Dates: {lv.startDate} to {lv.endDate}</div>
                      <p className="text-[10px] text-slate-500 line-clamp-2 italic">"{lv.reason}"</p>
                      {lv.reviewedBy && (
                        <div className="pt-2 text-[9px] border-t border-slate-100/60 text-indigo-600">
                          Reviewed by: <strong className="text-slate-600 font-medium">{lv.reviewedBy}</strong>
                          {lv.comments && <p className="text-slate-400 leading-normal mt-0.5">"{lv.comments}"</p>}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* CHAT WITH MENTOR MODULE */}
          {activeMenu === 'Student-Teacher Messages' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden text-left flex flex-col h-[520px]">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
                    <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Secured Monitored 1-on-1 Chat
                    </h4>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono">End-to-end encrypted school gateway</span>
                </div>
                {/* Contact Selection */}
                {currentUser.role === 'TEACHER' || currentUser.role === 'ADMIN' ? (
                  <div className="flex gap-2 text-xs">
                    <select 
                      value={chatTargetClass} 
                      onChange={e => { setChatTargetClass(e.target.value); setChatTargetUserId(null); }} 
                      className="p-2.5 border border-slate-200 rounded-lg cursor-pointer max-w-[150px]"
                    >
                      <option value="" disabled>Select Class</option>
                      {schoolClasses.map(cls => (
                        <option key={cls} value={cls}>{cls}</option>
                      ))}
                    </select>
                    <select 
                      value={chatTargetUserId || ''} 
                      onChange={e => setChatTargetUserId(e.target.value)} 
                      className="p-2.5 border border-slate-200 rounded-lg cursor-pointer flex-1"
                      disabled={!chatTargetClass}
                    >
                      <option value="" disabled>--- Select Student Contact ---</option>
                      {campusUsers.filter(u => (u.role === 'STUDENT' || u.role === 'PARENT') && u.details?.class === chatTargetClass).map(u => (
                        <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
                      ))}
                    </select>
                  </div>
                ) : (
                  <div className="flex gap-2 text-xs">
                    <select 
                      value={chatTargetUserId || ''} 
                      onChange={e => setChatTargetUserId(e.target.value)} 
                      className="p-2.5 border border-slate-200 rounded-lg cursor-pointer flex-1"
                    >
                      <option value="" disabled>--- Select Teacher to Chat ---</option>
                      {campusUsers.filter(u => u.role === 'TEACHER' || u.role === 'ADMIN').map(u => (
                         <option key={u.id} value={u.id}>
                           {u.name} - {u.details?.assignedSubject ? `(${u.details.assignedSubject} Teacher)` : `(${u.role})`}
                         </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Message Streams */}
              <div className="flex-1 p-4 overflow-y-auto space-y-4 font-sans text-xs bg-slate-50/30 relative">
                {!chatTargetUserId ? (
                  <div className="absolute inset-0 flex items-center justify-center text-slate-400 font-semibold p-6 text-center">
                    Select a contact from the dropdown above to start a direct secure conversation.
                  </div>
                ) : (
                  <>
                    {messages.filter(m => 
                      (m.senderId === currentUser.id && m.receiverId === chatTargetUserId) || 
                      (m.senderId === chatTargetUserId && m.receiverId === currentUser.id)
                    ).length === 0 && (
                      <div className="text-center text-slate-400 font-semibold py-8 italic">
                        No messages yet. Send the first message below.
                      </div>
                    )}
                    {messages.filter(m => 
                      (m.senderId === currentUser.id && m.receiverId === chatTargetUserId) || 
                      (m.senderId === chatTargetUserId && m.receiverId === currentUser.id)
                    ).map((m) => {
                      const isSentByMe = m.senderId === currentUser.id;
                      return (
                        <div key={m.id} className={`flex ${isSentByMe ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[75%] p-3.5 rounded-2xl relative space-y-1 ${
                            isSentByMe 
                              ? 'bg-indigo-600 text-white rounded-br-none' 
                              : 'bg-slate-100 text-slate-800 rounded-bl-none'
                          }`}>
                            <div className={`text-[8px] font-bold ${isSentByMe ? 'text-indigo-200' : 'text-slate-500'}`}>
                              {m.senderName} ({m.senderRole === 'PARENT' ? 'STUDENT CONTACT' : m.senderRole})
                            </div>
                            <p className="leading-relaxed whitespace-pre-line">{m.content}</p>
                            <div className={`text-[7px] text-right ${isSentByMe ? 'text-indigo-200/80' : 'text-slate-400'}`}>
                              {m.timestamp}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </>
                )}
                <div ref={chatBottomRef}></div>
              </div>

              {/* Chat Input form */}
              <form onSubmit={handleSendChatMessage} className="p-4 bg-slate-50 border-t border-slate-100 flex gap-2">
                <input
                  type="text"
                  placeholder="Type a respectful message to school members..."
                  className="flex-1 text-xs border border-slate-200 rounded-xl p-3 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/10 placeholder-slate-400 font-sans disabled:opacity-50"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  disabled={!chatTargetUserId}
                  required
                />
                <button
                  type="submit"
                  disabled={!chatTargetUserId}
                  className="bg-indigo-600 disabled:opacity-50 hover:bg-indigo-700 text-white text-xs font-bold px-5 py-3 rounded-xl flex items-center gap-1 transition-colors whitespace-nowrap cursor-pointer disabled:cursor-not-allowed"
                >
                  Send <Send className="w-3.5 h-3.5 ml-1" />
                </button>
              </form>
            </div>
          )}


          {/* ======================================= */}
          {/* TEACHER DASHBOARD DISPLAY VIEWS         */}
          {/* ======================================= */}

          {currentUser.role === 'TEACHER' && activeMenu === 'Overview' && (
            <div className="space-y-6 text-left">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold text-slate-800 mb-2">Teacher Cockpit Overview: Mrs. Sunita Rao</h3>
                <p className="text-xs text-slate-500">Mentorship Class: Grade 10-A | Mathematics HOD</p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                    <span className="text-xs text-slate-400 capitalize">Daily Attendance Status</span>
                    <div className="text-xl font-black text-emerald-600 mt-1">4 Present / 1 Absent</div>
                    <button onClick={() => setActiveMenu('Mark Attendance Roll')} className="text-[10px] text-indigo-600 font-bold hover:underline mt-2 inline-block">Trigger Daily Roll Call &rarr;</button>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                    <span className="text-xs text-slate-400 capitalize">Assigned Homework Segment</span>
                    <div className="text-xl font-black text-slate-800 mt-1">{homework.length} Active Tasks</div>
                    <button onClick={() => setActiveMenu('Publish School Homework')} className="text-[10px] text-indigo-600 font-bold hover:underline mt-2 inline-block">Post Mathematics Sheet &rarr;</button>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/50">
                    <span className="text-xs text-slate-400 capitalize">Upcoming PA-1 Science Schedule</span>
                    <div className="text-xl font-black text-indigo-600 mt-1">June 15, 2026</div>
                    <button onClick={() => setActiveMenu('Schedule Examination Desk')} className="text-[10px] text-indigo-600 font-bold hover:underline mt-2 inline-block">Configure Syllabus &rarr;</button>
                  </div>
                </div>
              </div>

              {/* Class roster and homework stats */}
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm font-sans text-xs">
                <h4 className="text-sm font-bold text-slate-800 mb-3 uppercase tracking-wider">Mentor Class Student Registry (Grade 10-A)</h4>
                <div className="divide-y divide-slate-100">
                  {[
                    { name: 'Aarav Kumar', roll: 'EIS-10A-14', attendance: 'Present', homeworkStatus: 'Submitted Math Sheet' },
                    { name: 'Diya Sharma', roll: 'EIS-10A-02', attendance: 'Present', homeworkStatus: 'Submitted Physics Lab' },
                    { name: 'Rohan Roy', roll: 'EIS-10A-23', attendance: 'Present', homeworkStatus: 'Pending' },
                    { name: 'Sneha Gupta', roll: 'EIS-10A-11', attendance: 'Absent', homeworkStatus: 'On Leave' },
                    { name: 'Amit Yadav', roll: 'EIS-10A-05', attendance: 'Present', homeworkStatus: 'Submitted Math Sheet' }
                  ].map((studentItem, sIdx) => (
                    <div key={sIdx} className="py-2.5 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 font-mono">
                          {studentItem.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-slate-800">{studentItem.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">Roll: {studentItem.roll}</div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          studentItem.attendance === 'Present' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                        }`}>
                          {studentItem.attendance}
                        </span>
                        <span className="text-slate-500 font-mono text-[10px]">{studentItem.homeworkStatus}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TEACHER GRADE STUDENT MARKS MODULE */}
          {currentUser.role === 'TEACHER' && activeMenu === 'Grade Student Marks' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left font-sans space-y-6">
              <div>
                <h3 className="text-lg font-extrabold text-[#2D3A3A] flex items-center gap-2">
                  ✍️ Enter & Update Student Marks
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Assign grades and publish periodic test results for academic trackers. All updates are immediately synced.
                </p>
              </div>

              {/* Class/Subject selectors */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200/60 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Target Class Room</label>
                  <select
                    value={examTargetClass}
                    onChange={(e) => {
                      setExamTargetClass(e.target.value);
                      setActiveEditingExamId(null);
                      // Auto switch subject if lost access
                      const isMentor = currentUser.details?.classTeacherOf === e.target.value;
                      if (!isMentor && currentUser.details?.assignedSubject) {
                        setExamSubject(currentUser.details.assignedSubject);
                      }
                    }}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-semibold text-slate-700 font-sans cursor-pointer"
                  >
                    {schoolClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Target Subject Scope</label>
                  <select
                    value={examSubject}
                    onChange={(e) => {
                      setExamSubject(e.target.value);
                      setActiveEditingExamId(null);
                    }}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-semibold text-slate-700 font-sans cursor-pointer"
                  >
                    {(() => {
                        const isMentor = currentUser.details?.classTeacherOf === examTargetClass;
                        const assignedSubject = currentUser.details?.assignedSubject || 'Mathematics';
                        const allSubjects = ['Mathematics', 'Science', 'Physics', 'Chemistry', 'Biology', 'English', 'Social Science', 'Computer Science'];
                        const subjectsToShow = isMentor ? allSubjects : [assignedSubject];
                        
                        return subjectsToShow.map(subj => (
                          <option key={subj} value={subj}>{subj}</option>
                        ));
                    })()}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Select Active Exam</label>
                  <select
                    value={activeEditingExamId || ''}
                    onChange={(e) => {
                      setActiveEditingExamId(e.target.value);
                      const ex = examsList.find(x => x.id === e.target.value);
                      if (ex) {
                        setNewHwTitle(ex.title);
                        // pre-fill marks if any
                        if (ex.publishedResults) {
                           setEditingStudentMarks(ex.publishedResults);
                        } else {
                           setEditingStudentMarks({});
                        }
                      }
                    }}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-semibold text-slate-700 font-sans cursor-pointer"
                  >
                    <option value="" disabled>--- Select Exam ---</option>
                    {examsList.filter(ex => ex.class === examTargetClass && ex.subject === examSubject).map(ex => (
                      <option key={ex.id} value={ex.id}>{ex.title} ({ex.date})</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Authority Checker Verification Shield */}
              {(() => {
                const assignedSub = currentUser.details?.assignedSubject || '';
                const classMentorOf = currentUser.details?.classTeacherOf || '';
                const hasSubjectRight = examSubject.toLowerCase() === assignedSub.toLowerCase();
                const hasClassMentorRight = examTargetClass === classMentorOf && classMentorOf !== 'None';
                const isAuthorized = hasSubjectRight || hasClassMentorRight;

                if (!isAuthorized) {
                  return (
                    <div className="p-5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl space-y-2">
                      <div className="flex items-center gap-2 font-bold text-xs text-rose-700">
                        <AlertCircle className="w-5 h-5 shrink-0" />
                        <span>UNAUTHORIZED SUITE PERMISSION DETECTED</span>
                      </div>
                      <p className="text-[11px] leading-relaxed">
                        As a specialized expert in <strong className="font-semibold text-rose-900">"{assignedSub}"</strong>, you have access to modify marks for other subjects ONLY for your mentoring Class Teachership class (<strong className="font-semibold text-rose-900">"{classMentorOf === 'None' || !classMentorOf ? 'None' : classMentorOf}"</strong>).
                      </p>
                      <p className="text-[11px] text-slate-500">
                        Please adjust the target class to <strong className="font-bold underline">"{classMentorOf}"</strong> or change the targeted subject to <strong className="font-bold underline">"{assignedSub}"</strong> to edit marks.
                      </p>
                    </div>
                  );
                }

                // Authorized! Render the dynamic mark-sheet!
                const matchedStudents = campusUsers.filter(u => u.role === 'STUDENT' && u.details?.class === examTargetClass);

                return (
                  <div className="space-y-4 border border-[#E0E4D9] p-4 rounded-xl">
                    <div className="flex items-center justify-between border-b pb-2">
                      <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded flex items-center gap-1">
                        ✓ Authorization Verified: {hasSubjectRight ? 'Subject Specialist' : 'Class Mentor Access'}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">Found {matchedStudents.length} Students in {examTargetClass}</span>
                    </div>

                    <div className="space-y-3">
                      {matchedStudents.map((st) => {
                        const currentVal = editingStudentMarks[st.name] ?? '90%';
                        return (
                          <div key={st.id} className="flex items-center justify-between bg-slate-50 p-3 rounded-lg border">
                            <div className="flex items-center gap-2">
                              <img src={st.avatar} className="w-8 h-8 rounded-full border shrink-0 object-cover" alt="" referrerPolicy="no-referrer" />
                              <div>
                                <h4 className="font-bold text-slate-800">{st.name}</h4>
                                <p className="text-[10px] text-slate-400 font-mono">Roll: {st.details?.rollNo} | Adm: {st.details?.admissionNo}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] text-slate-500 font-mono font-bold">Assign Percentage Score:</span>
                              <input
                                type="text"
                                value={currentVal}
                                onChange={(e) => {
                                  setEditingStudentMarks(prev => ({ ...prev, [st.name]: e.target.value }));
                                }}
                                className="w-16 border rounded text-center p-1.5 font-bold font-mono text-xs bg-white text-slate-800 focus:ring-2 focus:ring-indigo-500/20"
                                placeholder="e.g. 92%"
                              />
                            </div>
                          </div>
                        )
                      })}
                    </div>

                        <button
                          onClick={() => {
                            if (!activeEditingExamId) {
                               alert('Please select an active exam series from the dropdown to enter marks.');
                               return;
                            }
                            
                            // Merge marks
                            const updatedResultsObj: Record<string, string> = {};
                            matchedStudents.forEach(st => {
                              updatedResultsObj[st.name] = editingStudentMarks[st.name] ?? '90%';
                            });

                            setExamsList(prev => prev.map(ex => {
                              if (ex.id === activeEditingExamId) {
                                return { ...ex, publishedResults: updatedResultsObj };
                              }
                              return ex;
                            }));

                            // Email simulation notification helper
                            const notificationMsg = `Academic mark sheet compiled & successfully published! Students in "${examTargetClass}" can now review their grade scorecard in real-time.\n\n[SYSTEM SMS & EMAIL BOT] -> Automated report card notification sent to the registered email and phone number for the parents of ${examTargetClass}.`;

                            alert(notificationMsg);
                          }}
                          className="w-full bg-[#5A6F5A] hover:bg-[#495E49] text-white font-bold text-xs py-2.5 rounded-xl cursor-pointer shadow transition-colors block text-center uppercase tracking-wide"
                        >
                      Save & Publish Marksheet To Students Screen
                    </button>
                  </div>
                );
              })()}
            </div>
          )}

          {activeMenu === 'Mark Attendance Roll' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left">
              <h3 className="text-lg font-bold text-slate-800 mb-1">Mark Classroom Attendance</h3>
              <p className="text-xs text-slate-500 mb-6">Updating attendance record for Grade 10-A (Session Date: Today, {new Date().toISOString().split('T')[0]})</p>

              <div className="space-y-4 font-sans text-xs">
                {['Aarav Kumar', 'Diya Sharma', 'Rohan Roy', 'Sneha Gupta', 'Amit Yadav'].map((student) => (
                  <div key={student} className="p-4 rounded-xl border border-slate-100 bg-slate-50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="font-bold text-slate-800 text-sm">{student}</div>
                    
                    <div className="flex gap-2 text-xs">
                      {['Present', 'Absent', 'Late', 'Half-Day'].map((opt) => (
                        <button
                          key={opt}
                          onClick={() => toggleAttendanceRollCall(student, opt as any)}
                          className={`px-3 py-1.5 rounded-lg border font-semibold cursor-pointer transition-colors ${
                            rollCall[student] === opt 
                              ? opt === 'Present' 
                                ? 'bg-emerald-600 text-white border-emerald-600' 
                                : opt === 'Absent' ? 'bg-rose-600 text-white border-rose-600' : 'bg-amber-500 text-white border-amber-500'
                              : 'bg-white hover:bg-slate-100 text-slate-600'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}

                <button
                  onClick={() => {
                    setAttendanceMarkedToday(true);
                    alert(`Attendance updated securely under database registry. Parent SMS notifies pushed!`);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-5 py-3 rounded-lg cursor-pointer shadow mt-4 transition-colors"
                >
                  Submit Classroom Registry & Push SMS notifications
                </button>
              </div>
            </div>
          )}

          {activeMenu === 'Publish School Homework' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left">
              <h3 className="text-lg font-bold text-slate-800 mb-1">Publish homework Worksheet</h3>
              <p className="text-xs text-slate-500 mb-6">Post grade homework tasks to specific classrooms securely.</p>

              <form onSubmit={handlePublishHomework} className="space-y-4 font-sans text-xs">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-semibold text-slate-700">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Target Classroom</label>
                    <select
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white cursor-pointer"
                      value={newHwTargetClass}
                      onChange={e => {
                        setNewHwTargetClass(e.target.value);
                        // Auto-select subject if it's not their assigned subject and they are checking another class
                        const isMentor = currentUser.details?.classTeacherOf === e.target.value;
                        if (!isMentor && currentUser.details?.assignedSubject) {
                          setNewHwSubject(currentUser.details.assignedSubject);
                        }
                      }}
                    >
                      {schoolClasses.map(cls => (
                        <option key={cls} value={cls}>{cls}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Course Subject</label>
                    <select
                      className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white cursor-pointer"
                      value={newHwSubject}
                      onChange={e => setNewHwSubject(e.target.value)}
                    >
                      {(() => {
                        const isMentor = currentUser.details?.classTeacherOf === newHwTargetClass;
                        const assignedSubject = currentUser.details?.assignedSubject || 'Mathematics';
                        const allSubjects = ['Mathematics', 'Science', 'Physics', 'Chemistry', 'Biology', 'English', 'Social Science', 'Computer Science'];
                        const subjectsToShow = isMentor ? allSubjects : [assignedSubject];
                        
                        return subjectsToShow.map(subj => (
                          <option key={subj} value={subj}>{subj}</option>
                        ));
                      })()}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Homework Worksheet Title</label>
                    <input
                      type="text"
                      className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                      placeholder="e.g. Real Numbers Practice Set"
                      required
                      value={newHwTitle}
                      onChange={e => setNewHwTitle(e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-500 mb-1">Guidelines & Instructions</label>
                  <textarea
                    placeholder="Provide specific notes and exercises lists that pupils must complete clearly..."
                    className="w-full text-sm border border-slate-200 rounded-lg p-2.5 h-24 bg-white"
                    required
                    value={newHwDesc}
                    onChange={e => setNewHwDesc(e.target.value)}
                  ></textarea>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Submission Due Date</label>
                    <input
                      type="date"
                      className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                      required
                      value={newHwDueDate}
                      onChange={e => setNewHwDueDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Attach Worksheet/File Option (Optional)</label>
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf"
                      className="w-full text-sm border border-slate-200 rounded-lg p-1.5 bg-white file:mr-4 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
                      onChange={e => {
                        if (e.target.files && e.target.files[0]) {
                          setHwAttachment(e.target.files[0]);
                        }
                      }}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-5 py-3 rounded-lg transition-colors cursor-pointer"
                >
                  Broadcast Homework Worksheet
                </button>
              </form>
            </div>
          )}

          {activeMenu === 'Schedule Examination Desk' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
              <div className="md:col-span-1 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                <h4 className="text-sm font-bold text-slate-800 uppercase tracking-wide">
                  Schedule Periodic Subtest
                </h4>
                <form onSubmit={handleScheduleExamSubmit} className="space-y-4 font-sans text-xs">
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Exam Title</label>
                    <input
                      type="text"
                      placeholder="e.g. Unit Test 1"
                      className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                      value={newHwTitle}
                      onChange={(e) => setNewHwTitle(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Course Subject</label>
                    <select
                      className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                      value={examSubject}
                      onChange={e => setExamSubject(e.target.value)}
                    >
                      <option value="Mathematics">Mathematics</option>
                      <option value="Science">Science</option>
                      <option value="Social Science">Social Science</option>
                      <option value="English">English</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Target Class</label>
                    <select
                      className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                      value={examTargetClass}
                      onChange={e => setExamTargetClass(e.target.value)}
                    >
                      {schoolClasses.map(cls => (
                        <option key={cls} value={cls}>{cls}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Exam Date</label>
                    <input
                      type="date"
                      className="w-full text-sm border border-slate-200 rounded-lg p-2 bg-white"
                      required
                      value={examDate}
                      onChange={e => setExamDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1">Active Syllabus</label>
                    <textarea
                      placeholder="Chapters 4 & 5 Quadratic sets..."
                      className="w-full text-sm border border-slate-200 rounded-lg p-2.5 h-20 bg-white"
                      required
                      value={examSyllabus}
                      onChange={e => setExamSyllabus(e.target.value)}
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 rounded-lg transition-colors cursor-pointer animate-pulse"
                  >
                    Schedule Test
                  </button>
                </form>
              </div>

              {/* Roster examinations list */}
              <div className="md:col-span-2 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                <h4 className="text-sm font-bold text-slate-800 uppercase tracking-medium border-b border-slate-100 pb-2">Completed & Scheduled Assessments</h4>
                <div className="divide-y divide-slate-100 font-sans text-xs">
                  {examsList.map((ex) => (
                    <div key={ex.id} className="py-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-xs bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-bold">{ex.subject}</span>
                          <h5 className="font-bold text-slate-800 mt-1">{ex.title}</h5>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">Date: {ex.date} | {ex.duration}</span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1"><strong className="text-slate-600">Syllabus:</strong> {ex.syllabus}</p>
                      {ex.publishedResults && (
                        <div className="mt-2 text-[10px] bg-emerald-50 text-emerald-800 p-2 rounded border border-emerald-100">
                          <strong>Grades published:</strong> Aarav Kumar ({ex.publishedResults['Aarav Kumar']}) | Diya Sharma ({ex.publishedResults['Diya Sharma']})
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}


          {/* ======================================= */}
          {/* SUPER ADMIN CONTROL MODULES             */}
          {/* ======================================= */}

          {currentUser.role === 'ADMIN' && activeMenu === 'Overview' && (
            <div className="space-y-6 text-left font-sans text-xs">
              <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 text-white relative">
                <div className="absolute top-0 right-0 p-6 text-amber-500/10">
                  <GraduationCap className="h-28 w-28" />
                </div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-amber-400">Super Admin Workspace</span>
                <h3 className="text-xl font-bold mt-1">Hello, {currentUser.name}</h3>
                <p className="text-xs text-slate-400 mt-1">Managing Director counsel operations | EIS Dharuhera Council</p>

                {/* Main statistics grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  <div className="p-4 bg-slate-800 rounded-xl border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 uppercase">Active Students Enrolled</span>
                    <div className="text-lg font-black text-amber-400 mt-1">1,240 Pupils</div>
                  </div>
                  <div className="p-4 bg-slate-800 rounded-xl border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 uppercase">Professional Faculty</span>
                    <div className="text-lg font-black text-white mt-1">74 Teachers</div>
                  </div>
                  <div className="p-4 bg-slate-800 rounded-xl border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 uppercase">Quarter 1 Fees Collected</span>
                    <div className="text-lg font-black text-emerald-400 mt-1">₹1,54,32,000</div>
                  </div>
                  <div className="p-4 bg-slate-800 rounded-xl border border-slate-700/60">
                    <span className="text-[10px] text-slate-400 uppercase">Active GPS Route Buses</span>
                    <div className="text-lg font-black text-indigo-400 mt-1">14/16 Transit</div>
                  </div>
                </div>
              </div>

              {/* Quick actions links */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-white rounded-xl border border-slate-100 flex items-center justify-between shadow-sm">
                  <div>
                    <h5 className="font-bold text-slate-800">Broadcast Core Notices</h5>
                    <p className="text-[10px] text-slate-400">Post announcements to parent notices reels</p>
                  </div>
                  <button onClick={() => setActiveMenu('Broadcast Core Notices')} className="bg-indigo-100 text-indigo-700 font-bold px-3 py-1.5 rounded-md hover:bg-slate-200 cursor-pointer">Post Notice</button>
                </div>
                <div className="p-4 bg-white rounded-xl border border-slate-100 flex items-center justify-between shadow-sm">
                  <div>
                    <h5 className="font-bold text-slate-800">Review Leave Applications</h5>
                    <p className="text-[10px] text-slate-400">Review and approve parent requested absences</p>
                  </div>
                  <button onClick={() => setActiveMenu('Review Leave Petitions')} className="bg-indigo-100 text-indigo-700 font-bold px-3 py-1.5 rounded-md hover:bg-slate-200 cursor-pointer">View List</button>
                </div>
              </div>
            </div>
          )}

          {activeMenu === 'Manage Academic Faculty' && currentUser.role === 'ADMIN' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left font-sans space-y-6">
              <div>
                <h3 className="text-base font-extrabold text-slate-800 flex items-center gap-1.5">
                  🎓 Manage Academic Professional Faculty
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Assign specialized taught subjects and set dedicated Class Teachership mentorship bounds in real-time.
                </p>
              </div>

              <div className="space-y-4">
                {campusUsers.filter(u => u.role === 'TEACHER').map((tch) => (
                  <div key={tch.id} className="p-4 border border-slate-200/60 rounded-2xl bg-[#F9FAF7] space-y-4 shadow-sm">
                    <div className="flex items-center gap-3 w-full justify-between">
                      <div className="flex items-center gap-3">
                        <img src={tch.avatar} className="w-10 h-10 rounded-full border object-cover shrink-0" alt="" referrerPolicy="no-referrer" />
                        <div>
                          <h4 className="font-bold text-slate-800 text-xs">{tch.name}</h4>
                          <p className="text-[10px] text-slate-400 font-mono">{tch.email} | Phone: {tch.details?.phone}</p>
                        </div>
                      </div>
                      <span className="text-[9px] font-bold text-emerald-700 font-mono tracking-wider bg-emerald-50 py-1 px-2 rounded uppercase border border-emerald-100">
                        Faculty Member
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                          Assigned Subject Specialist Taught:
                        </label>
                        <select
                          value={tch.details?.assignedSubject || 'Mathematics'}
                          onChange={(e) => {
                            const updatedVal = e.target.value;
                            setCampusUsers(prev => prev.map(u => u.id === tch.id ? {
                              ...u,
                              details: {
                                ...u.details,
                                assignedSubject: updatedVal
                              }
                            } : u));
                            alert(`Subject authority updated successfully. ${tch.name} is now the specialist expert of "${updatedVal}".`);
                          }}
                          className="bg-white border border-slate-200 rounded p-2 font-bold w-full text-slate-700 font-sans cursor-pointer focus:border-[#5A6F5A] focus:ring-1 focus:ring-[#5A6F5A]"
                        >
                          <option value="Mathematics">Mathematics</option>
                          <option value="Science">Science</option>
                          <option value="English">English</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">
                          Designate Class Teachership:
                        </label>
                        <select
                          value={tch.details?.classTeacherOf || 'None'}
                          onChange={(e) => {
                            const updatedVal = e.target.value;
                            setCampusUsers(prev => prev.map(u => u.id === tch.id ? {
                              ...u,
                              details: {
                                ...u.details,
                                classTeacherOf: updatedVal
                              }
                            } : u));
                            alert(`Mentorship class reassigned successfully. ${tch.name} is now designated as Class Mentor of "${updatedVal}".`);
                          }}
                          className="bg-white border border-slate-200 rounded p-2 font-bold w-full text-slate-700 font-sans cursor-pointer focus:border-[#5A6F5A] focus:ring-1 focus:ring-[#5A6F5A]"
                        >
                          <option value="None">None (Floating Mentor)</option>
                          {schoolClasses.map(cls => (
                            <option key={cls} value={cls}>{cls}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-600 bg-white p-3 rounded-lg font-medium leading-relaxed border border-[#E0E4D9]">
                      🛡️ <strong>Live Profile Security Sync Active:</strong> {tch.name} can upload assignments and schedule exams of other subjects inside their Class Teachership room (<strong className="text-slate-900">"{tch.details?.classTeacherOf || 'None'}"</strong>), and can only edit and upload their specialized subject ("<strong>{tch.details?.assignedSubject}</strong>") elsewhere on school campus.
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeMenu === 'Manage Class Structure' && currentUser.role === 'ADMIN' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-8">
              <div>
                <h3 className="text-lg font-bold text-slate-800">Establish Classes & Enroll Pupils</h3>
                <p className="text-xs text-slate-500">Add classrooms or admit new students into specific active tracks.</p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Add new Class */}
                <div className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <h4 className="text-sm font-bold text-slate-700 underline underline-offset-4 decoration-indigo-200 decoration-2">
                    Create New Division Level
                  </h4>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (!newClassName) return;
                    setSchoolClasses(prev => {
                      if (!prev.includes(newClassName)) {
                         return [...prev, newClassName];
                      }
                      return prev;
                    });
                    alert(`Division tracking created: ${newClassName} successfully established.`);
                    setNewClassName('');
                  }} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1">Standard/Section Format Label</label>
                      <input
                        type="text"
                        placeholder="e.g. Grade 11-Science"
                        className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white"
                        required
                        value={newClassName}
                        onChange={e => setNewClassName(e.target.value)}
                      />
                    </div>
                    <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2 rounded-lg cursor-pointer">
                      Approve & Register Section
                    </button>
                  </form>
                  <div className="mt-4">
                    <h5 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Currently Active Classes</h5>
                    <div className="flex flex-wrap gap-2">
                       {schoolClasses.map(cls => (
                          <span key={cls} className="text-[10px] bg-slate-200 text-slate-700 px-2 py-1 rounded font-bold">{cls}</span>
                       ))}
                    </div>
                  </div>
                </div>

                {/* Add new Student */}
                <div className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <h4 className="text-sm font-bold text-slate-700 underline underline-offset-4 decoration-emerald-200 decoration-2">
                    Enroll New Scholar Profile
                  </h4>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (!newStudentName || !newStudentPhone) return;
                    const newStudent: User = {
                      id: `USR_STUDENT_${Date.now().toString().slice(-4)}`,
                      name: newStudentName,
                      email: `${newStudentName.replace(' ', '.').toLowerCase()}@eurodharuhera.edu.in`,
                      role: 'STUDENT',
                      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
                      details: {
                        class: newHwTargetClass || 'Grade 10-A',
                        rollNo: `EIS-${newHwTargetClass.split('-')[1]?.[0] || '10'}-${Math.floor(Math.random() * 1000)}`,
                        phone: newStudentPhone,
                        gender: newStudentGender as any,
                        admissionNo: `ADM-${Date.now().toString().slice(-6)}`
                      }
                    };
                    setCampusUsers(prev => [...prev, newStudent]);
                    alert(`Scholar records fully activated for ${newStudentName}. Phone login enabled for: ${newStudentPhone}. App login uses last 5 digits of phone as password initially.`);
                    setNewStudentName('');
                    setNewStudentPhone('');
                  }} className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="col-span-2">
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Target Dimension (Class)</label>
                        <select
                          className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white cursor-pointer"
                          value={newHwTargetClass}
                          onChange={e => setNewHwTargetClass(e.target.value)}
                        >
                          {schoolClasses.map(cls => (
                            <option key={cls} value={cls}>{cls}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>

                        <input
                          type="text"
                          className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                          required
                          value={newStudentName}
                          onChange={e => setNewStudentName(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Gender</label>
                        <select
                          className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                          value={newStudentGender}
                          onChange={e => setNewStudentGender(e.target.value)}
                        >
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Parent Phone Identity Tracking</label>
                        <input
                          type="text"
                          className="w-full text-[10px] uppercase font-mono tracking-wider border border-slate-200 rounded-lg p-2 bg-white"
                          required
                          placeholder="e.g. 9812300000"
                          value={newStudentPhone}
                          onChange={e => setNewStudentPhone(e.target.value)}
                        />
                      </div>
                    </div>
                    <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2 rounded-lg cursor-pointer">
                      Generate Unified Identity DB
                    </button>
                  </form>
                </div>

                {/* Add new Teacher */}
                <div className="space-y-4 bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <h4 className="text-sm font-bold text-slate-700 underline underline-offset-4 decoration-amber-200 decoration-2">
                    Enroll New Faculty Profile
                  </h4>
                  <form onSubmit={(e) => {
                    e.preventDefault();
                    if (!newTeacherName || !newTeacherPhone) return;
                    const newTeacher: User = {
                      id: `USR_TEACH_${Date.now().toString().slice(-4)}`,
                      name: newTeacherName,
                      email: `${newTeacherName.replace(' ', '.').toLowerCase()}@eurodharuhera.edu.in`,
                      role: 'TEACHER',
                      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
                      details: {
                        class: newTeacherClass,
                        employeeId: `EIS-TCH-${Math.floor(Math.random() * 1000)}`,
                        phone: newTeacherPhone,
                        designation: `${newTeacherSubject} Educator`,
                        gender: newTeacherGender as any,
                        assignedSubject: newTeacherSubject,
                        classTeacherOf: newTeacherClass !== 'None' ? newTeacherClass : undefined
                      }
                    };
                    setCampusUsers(prev => [...prev, newTeacher]);
                    alert(`Faculty records fully activated for ${newTeacherName}. Phone login enabled for: ${newTeacherPhone}. App login uses last 5 digits of phone as password initially.`);
                    setNewTeacherName('');
                    setNewTeacherPhone('');
                  }} className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="col-span-2">
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Class Teachership (Optional)</label>
                        <select
                          className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white cursor-pointer"
                          value={newTeacherClass}
                          onChange={e => setNewTeacherClass(e.target.value)}
                        >
                          <option value="None">None</option>
                          {schoolClasses.map(cls => (
                            <option key={cls} value={cls}>{cls}</option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-2">
                         <label className="block text-xs font-semibold text-slate-500 mb-1">Subject Taught</label>
                         <select
                           className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-white cursor-pointer"
                           value={newTeacherSubject}
                           onChange={e => setNewTeacherSubject(e.target.value)}
                         >
                            <option value="Mathematics">Mathematics</option>
                            <option value="Science">Science</option>
                            <option value="Physics">Physics</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Biology">Biology</option>
                            <option value="English">English</option>
                            <option value="Social Science">Social Science</option>
                            <option value="Computer Science">Computer Science</option>
                         </select>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Full Name</label>
                        <input
                          type="text"
                          className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                          required
                          value={newTeacherName}
                          onChange={e => setNewTeacherName(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Gender</label>
                        <select
                          className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                          value={newTeacherGender}
                          onChange={e => setNewTeacherGender(e.target.value)}
                        >
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                      <div className="col-span-2">
                        <label className="block text-xs font-semibold text-slate-500 mb-1">Phone Login Identity</label>
                        <input
                          type="text"
                          className="w-full text-[10px] uppercase font-mono tracking-wider border border-slate-200 rounded-lg p-2 bg-white"
                          required
                          placeholder="e.g. 9812300000"
                          value={newTeacherPhone}
                          onChange={e => setNewTeacherPhone(e.target.value)}
                        />
                      </div>
                    </div>
                    <button type="submit" className="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs py-2 rounded-lg cursor-pointer">
                      Register Faculty Profile
                    </button>
                  </form>
                </div>
              </div>

              {/* Add Exams wrapper component */}
              <div className="space-y-4 pt-6 border-t border-slate-100">
                <h3 className="text-lg font-bold text-slate-800">Establish School Term Examinations</h3>
                <p className="text-xs text-slate-500 mb-4">Define central exam sessions. Mentors will be notified to begin uploading mark sheets accordingly.</p>
                <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Exam Series Title</label>
                      <input
                        type="text"
                        placeholder="e.g. Midterm Exams"
                        className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                        value={newHwTitle}
                        onChange={(e) => setNewHwTitle(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Subject Scope</label>
                      <select
                        className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white cursor-pointer"
                        value={examSubject}
                        onChange={(e) => setExamSubject(e.target.value)}
                      >
                        <option value="Mathematics">Mathematics</option>
                        <option value="Science">Science</option>
                        <option value="Social Science">Social Science</option>
                        <option value="English">English</option>
                        <option value="Computer Science">Computer Science</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Target Standard</label>
                      <select
                        value={examTargetClass}
                        onChange={(e) => setExamTargetClass(e.target.value)}
                        className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white cursor-pointer"
                      >
                        {schoolClasses.map(cls => (
                          <option key={cls} value={cls}>{cls}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Begin Timeline</label>
                      <input
                        type="date"
                        className="w-full text-xs border border-slate-200 rounded-lg p-2 bg-white"
                        value={examDate}
                        onChange={(e) => setExamDate(e.target.value)}
                      />
                    </div>
                    <div className="flex items-end">
                      <button
                        onClick={() => {
                          if (!examSubject || !examDate || !newHwTitle) return;
                          setExamsList(prev => [...prev, {
                            id: `EXM-${Date.now()}`,
                            title: newHwTitle,
                            subject: examSubject,
                            class: examTargetClass,
                            date: examDate,
                            duration: "2 Hours",
                            syllabus: "Term standard curriculum module",
                            publishedResults: {}
                          }]);
                          setNewHwTitle('');
                          alert(`Global notice activated: Official schedule published for ${newHwTitle} covering ${examTargetClass}. Instructors alerted for sheet duties!`);
                        }}
                        className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold text-[10px] uppercase tracking-wider py-2.5 rounded-lg transition-colors cursor-pointer"
                      >
                        Init Terminal Series
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeMenu === 'Broadcast Core Notices' && currentUser.role === 'ADMIN' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left">
              <NoticeBoard circulars={circulars} onAddCircular={handleAddCircular} showAdminActions={true} />
            </div>
          )}

          {activeMenu === 'Review Leave Petitions' && (currentUser.role === 'ADMIN' || currentUser.role === 'TEACHER') && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-4">
              <h3 className="text-lg font-bold text-slate-800">Review Pupil Leave Applications</h3>
              <p className="text-xs text-slate-500">Inspect leave requests with real-time approval capabilities.</p>

              <div className="divide-y divide-slate-100 font-sans text-xs">
                {leaves.filter(lv => currentUser.role === 'ADMIN' || lv.class === currentUser.details?.classTeacherOf).map((lv) => (
                  <div key={lv.id} className="py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-800">{lv.studentName} ({lv.class})</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold ${
                          lv.status === 'Approved' 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : lv.status === 'Rejected' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800 animate-pulse'
                        }`}>
                          {lv.status}
                        </span>
                      </div>
                      <p className="text-slate-500">Proposed Range: {lv.startDate} to {lv.endDate}</p>
                      <p className="text-slate-600 italic">"Reason: {lv.reason}"</p>
                    </div>

                    {lv.status === 'Pending' && (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApproveLeave(lv.id, 'Approved')}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg cursor-pointer"
                        >
                          Approve Leave
                        </button>
                        <button
                          onClick={() => handleApproveLeave(lv.id, 'Rejected')}
                          className="bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs px-3 py-1.5 rounded-lg cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </div>
                ))}
                {leaves.filter(lv => currentUser.role === 'ADMIN' || lv.class === currentUser.details?.classTeacherOf).length === 0 && (
                  <div className="py-8 text-center text-slate-500">No pending leave applications available for your assigned domains.</div>
                )}
              </div>
            </div>
          )}


          {/* ======================================= */}
          {/* STAFF & TRANSPORT OPERATIONS MODULES     */}
          {/* ======================================= */}

          {(currentUser.role === 'STAFF_TRANSPORT' || activeMenu === 'Transport Operations') && currentUser.role === 'STAFF_TRANSPORT' && (
            <div className="space-y-6 text-left font-sans text-xs">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-1">Logistics & Route Dispatches</h3>
                <p className="text-xs text-slate-500 mb-6">Operations dashboard managed by {currentUser.name}</p>
                <TransportMap route={busRoute} currentUser={currentUser} />
              </div>
            </div>
          )}

          {activeMenu === 'Account Fee Tracking' && currentUser.role === 'STAFF_TRANSPORT' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm text-left space-y-4">
              <h3 className="text-lg font-bold text-slate-800">Global Student Invoices Clearance Dashboard</h3>
              <p className="text-xs text-slate-500">Overview of all tuition invoices collected at Euro accounts.</p>
              
              <div className="divide-y divide-slate-100 font-sans text-xs">
                {invoices.map((inv) => (
                  <div key={inv.id} className="py-3 flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-800">{inv.term}</span>
                      <p className="text-slate-400">Issued On: {inv.issueDate} | Code: {inv.id}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-slate-800">₹{inv.totalAmount.toLocaleString('en-IN')}</div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {inv.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* ======================================= */}
      {/* GLOBAL MODALS ACCORDION SECURE SYSTEMS */}
      {/* ======================================= */}

      {/* 1. STUDENT HOMEWORK SUBMISSION POPUP */}
      <AnimatePresence>
      {selectedHomeWorkId && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        >
          <motion.div 
            initial={{ y: 50, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 20, opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", bounce: 0.3, duration: 0.4 }}
            className="bg-white rounded-2xl border border-slate-100 shadow-xl max-w-md w-full p-6 text-left relative space-y-4"
          >
            <button
              onClick={() => setSelectedHomeworkId(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
            <h4 className="text-sm font-bold text-slate-800 uppercase tracking-widest flex items-center gap-1">
              🚀 Post Homework File to School Portal
            </h4>
            <p className="text-xs text-slate-500 leading-normal">
              Confirm your assignment attachment upload. Your tutor Mrs. Sunita Rao will receive notification immediately.
            </p>

            <form onSubmit={handleSubmitHomework} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">Type Attachment File Name</label>
                <input
                  type="text"
                  placeholder="e.g. EIS_Quadratic_Sheet_Aarav.pdf"
                  required
                  className="w-full text-xs border border-slate-200 rounded-lg p-2.5 bg-slate-50 mb-2"
                  value={homeworkUploadName}
                  onChange={e => setHomeworkUploadName(e.target.value)}
                />
                
                <label className="block text-[10px] font-bold text-slate-400 mb-1">Upload Local File</label>
                <input
                  type="file"
                  accept=".jpg,.jpeg,.png,.pdf"
                  required
                  className="w-full text-xs border border-slate-200 rounded-lg p-1.5 bg-white file:mr-4 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-[10px] file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer"
                  onChange={e => {
                    if (e.target.files && e.target.files[0]) {
                      setStudentHwAttachment(e.target.files[0]);
                      setHomeworkUploadName(e.target.files[0].name);
                    }
                  }}
                />
              </div>

              <div className="p-3 bg-amber-50 border border-amber-100 text-[10px] text-amber-800 rounded-lg">
                📝 Note: The platform simulates a secure Drag-and-Drop file analyzer upload of PDF schemas.
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-2.5 rounded-lg transition-colors cursor-pointer"
              >
                Upload & Clear Deadline Task
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
      </AnimatePresence>

      {/* 2. SECURE PORTAL FEE CHECKOUT MODAL */}
      <AnimatePresence>
      {selectedInvoiceForPayment && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        >
          <motion.div 
            initial={{ y: 50, opacity: 0, scale: 0.95 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 20, opacity: 0, scale: 0.95 }}
            transition={{ type: "spring", bounce: 0.3, duration: 0.4 }}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-left relative space-y-4 font-sans"
          >
            <button
              onClick={() => setSelectedInvoiceForPayment(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            {!paymentCompleted ? (
              <>
                <div className="flex items-center gap-2 text-indigo-600">
                  <CreditCard className="w-5 h-5" />
                  <h4 className="text-sm font-black uppercase tracking-wider">Secured RazorPay Gateway</h4>
                </div>
                
                <div className="space-y-2 pt-2 pb-4 border-b border-slate-100">
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Beneficiary Account</span>
                    <strong className="text-slate-800">Euro International School Dharuhera</strong>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500">
                    <span>Active Term</span>
                    <strong className="text-slate-800">{selectedInvoiceForPayment.term}</strong>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-slate-800 pt-2">
                    <span>Gross Settlement</span>
                    <span>₹{selectedInvoiceForPayment.totalAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <form onSubmit={handleFeePaymentSubmit} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-bold text-slate-400 uppercase text-[9px] mb-1">Card Holder Information</label>
                    <input
                      type="text"
                      className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50"
                      required
                      placeholder="e.g. ALOK KUMAR"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-400 uppercase text-[9px] mb-1">Card Number (16 Digits)</label>
                    <input
                      type="text"
                      className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50"
                      required
                      maxLength={19}
                      placeholder="e.g. 4532 9981 2049 8830"
                      value={cardNumber}
                      onChange={e => setCardNumber(e.target.value)}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-slate-400 uppercase text-[9px] mb-1">Expiry Date (MM/YY)</label>
                      <input
                        type="text"
                        className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50"
                        required
                        placeholder="MM/YY"
                        value={cardExpiry}
                        onChange={e => setCardExpiry(e.target.value)}
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-400 uppercase text-[9px] mb-1">Secure CVV</label>
                      <input
                        type="password"
                        className="w-full p-2.5 border border-slate-200 rounded-lg bg-slate-50"
                        required
                        maxLength={3}
                        placeholder="• • •"
                        value={cardCVV}
                        onChange={e => setCardCVV(e.target.value)}
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isPayingFee}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs py-3 rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isPayingFee ? (
                      <>
                        <div className="w-4 h-4 rounded-full border-2 border-slate-200 border-t-transparent animate-spin"></div>
                        <span>Processing Bank Settlement...</span>
                      </>
                    ) : (
                      <>
                        <span>Clear Clearance Fee Settlement</span>
                      </>
                    )}
                  </button>
                </form>
              </>
            ) : (
              <div className="text-center py-6 space-y-4">
                <div className="h-16 w-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-50 shadow animate-bounce">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-lg font-bold text-slate-900">Settlement Successful!</h4>
                  <p className="text-xs text-slate-400">Transaction code logged: TXN-HDFC-{Math.floor(1000000 + Math.random() * 9000000)}</p>
                </div>
                <p className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-100">
                  Your Quarter Fee of <strong>₹{selectedInvoiceForPayment.totalAmount.toLocaleString('en-IN')}</strong> has been secured and settled into school trust fund accounts under student Aarav Kumar.
                </p>
                <button
                  onClick={() => setSelectedInvoiceForPayment(null)}
                  className="bg-slate-900 text-white font-bold text-xs px-5 py-2.5 rounded-lg cursor-pointer hover:bg-slate-800"
                >
                  Return to portal financials
                </button>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
      </AnimatePresence>

      {/* HIDDEN DIGITAL ID CARD FOR PDF GENERATION */}
      <div 
        id="student-id-card-view" 
        className="w-[204px] h-[325px] bg-white hidden absolute"
      >
        <div className="w-full h-full border-[3px] border-slate-900 rounded-lg overflow-hidden flex flex-col relative bg-slate-50">
          <div className="bg-slate-900 p-2 text-center flex flex-col items-center">
            <img src={eisLogo} alt="Logo" className="w-8 h-8 object-cover mix-blend-screen bg-white rounded p-0.5 mb-1" />
            <h1 className="text-white text-[10px] font-black leading-none uppercase tracking-wide">Euro International</h1>
            <p className="text-amber-400 text-[6px] uppercase tracking-widest mt-0.5">School Dharuhera</p>
          </div>
          <div className="flex-1 flex flex-col items-center p-3 relative z-10">
            <div className="w-20 h-20 rounded-full border-2 border-slate-900 p-1 mb-2 bg-white">
              <img src={currentUser.avatar} alt="Profile" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
            </div>
            <h2 className="text-sm font-black text-slate-900 uppercase tracking-tight text-center leading-tight mb-1">{currentUser.name}</h2>
            <div className="text-[9px] font-bold text-slate-600 bg-slate-200 px-2 py-0.5 rounded uppercase tracking-wider mb-3">
              {currentUser.role}
            </div>
            
            <div className="w-full space-y-1 mt-auto">
              {currentUser.details?.class && (
                <div className="flex justify-between text-[8px]">
                  <span className="text-slate-500 font-bold">CLASS:</span>
                  <span className="text-slate-900 font-black">{currentUser.details.class}</span>
                </div>
              )}
              {currentUser.details?.rollNo && (
                <div className="flex justify-between text-[8px]">
                  <span className="text-slate-500 font-bold">ROLL NO:</span>
                  <span className="text-slate-900 font-black">{currentUser.details.rollNo}</span>
                </div>
              )}
              {currentUser.details?.admissionNo && (
                <div className="flex justify-between text-[8px]">
                  <span className="text-slate-500 font-bold">ADM NO:</span>
                  <span className="text-slate-900 font-black">{currentUser.details.admissionNo}</span>
                </div>
              )}
              {currentUser.details?.phone && (
                <div className="flex justify-between text-[8px]">
                  <span className="text-slate-500 font-bold">EMERGENCY:</span>
                  <span className="text-slate-900 font-black">{currentUser.details.phone}</span>
                </div>
              )}
            </div>
          </div>
          <div className="bg-amber-400 p-1.5 text-center">
            <p className="text-[6px] font-black text-slate-900 uppercase">Property of EIS Dharuhera</p>
          </div>
        </div>
      </div>

    </div>
  );
}
