import { useState, useEffect, useRef } from 'react';
import { BusRoute, User } from '../types';
import { Bus, MapPin, Phone, UserCheck, Shield, Clock, Navigation, CheckCircle2, AlertTriangle } from 'lucide-react';
import { APIProvider, Map, AdvancedMarker, Pin, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';

interface TransportMapProps {
  route: BusRoute;
  currentUser: User;
}

const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

function RouteDisplay({ origin, destination, waypoints }: {
  origin: google.maps.LatLngLiteral;
  destination: google.maps.LatLngLiteral;
  waypoints: google.maps.LatLngLiteral[];
}) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylinesRef = useRef<google.maps.Polyline[]>([]);

  useEffect(() => {
    if (!routesLib || !map) return;
    
    // Clear previous route
    polylinesRef.current.forEach(p => p.setMap(null));

    const waypointsArray = waypoints.map(location => ({
        location,
        stopover: true
    }));

    routesLib.Route.computeRoutes({
      origin,
      destination,
      intermediates: waypointsArray,
      travelMode: 'DRIVING' as any,
      fields: ['path', 'distanceMeters', 'durationMillis', 'viewport'],
    }).then(({ routes }) => {
      if (routes?.[0]) {
        const newPolylines = routes[0].createPolylines();
        newPolylines.forEach(p => p.setMap(map));
        polylinesRef.current = newPolylines;
        if (routes[0].viewport) map.fitBounds(routes[0].viewport);
      }
    }).catch(err => console.log('Route calculation failed:', err));

    return () => polylinesRef.current.forEach(p => p.setMap(null));
  }, [routesLib, map, origin, destination, waypoints]);

  return null;
}

export function TransportMap({ route, currentUser }: TransportMapProps) {
  const [eta, setEta] = useState(route.etaMinutes);
  const [busStatus, setBusStatus] = useState<BusRoute['status']>('In-Transit');
  
  // Handle manual delay trigger for demo purposes
  const triggerSimulateDelay = () => {
    if (busStatus === 'In-Transit') {
      setBusStatus('Delayed');
      setEta((prev) => prev + 15);
    } else {
      setBusStatus('In-Transit');
      setEta(route.etaMinutes);
    }
  };

  // Example waypoints for a school bus route 
  const origin = { lat: 28.2046, lng: 76.7844 }; // Dharuhera coordinates roughly
  const destination = { lat: 28.2140, lng: 76.7900 }; 
  const waypoints = [
    { lat: 28.2080, lng: 76.7860 },
    { lat: 28.2100, lng: 76.7880 }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Visual GPS MAP panel */}
      <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden flex flex-col min-h-[420px] relative">
        <div className="p-4 bg-slate-50 border-b border-rose-100/30 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="flex h-2.5 w-2.5 relative">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${busStatus === 'Delayed' ? 'bg-amber-400' : 'bg-emerald-400'}`}></span>
              <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${busStatus === 'Delayed' ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
            </span>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Live GPS Feed & Route Tracker
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-full font-mono">
              Vehicle: {route.busNumber}
            </span>
            <button 
              onClick={triggerSimulateDelay} 
              className="text-xs text-rose-600 hover:text-rose-700 font-medium flex items-center gap-1 border border-rose-200 rounded px-2 py-0.5 bg-rose-50 hover:bg-rose-100 transition-colors cursor-pointer"
            >
              {busStatus === 'Delayed' ? 'Reset Bus Status' : 'Simulate Traffic Delay'}
            </button>
          </div>
        </div>

        {/* Dynamic Vector/Grid Canvas Map */}
        <div className="flex-1 overflow-hidden relative min-h-[300px] flex items-center justify-center bg-slate-100">
          {!hasValidKey ? (
            <div style={{textAlign:'center',maxWidth:520, padding: 20}}>
              <h2 className="font-bold text-slate-800 mb-2">Google Maps API Key Required</h2>
              <p className="text-xs text-slate-600 mb-2"><strong>Step 1:</strong> <a href="https://console.cloud.google.com/google/maps-apis/start" target="_blank" rel="noopener" className="text-indigo-600">Get an API Key</a></p>
              <p className="text-xs text-slate-600 mb-1"><strong>Step 2:</strong> Add your key as a secret:</p>
              <ul className="text-left text-xs text-slate-500 list-disc ml-6 space-y-1">
                <li>Open Settings (⚙️ gear icon, top-right)</li>
                <li>Select Secrets</li>
                <li>Type <code>GOOGLE_MAPS_PLATFORM_KEY</code> as the name, press Enter</li>
                <li>Paste your API key as the value, press Enter</li>
              </ul>
            </div>
          ) : (
            <APIProvider apiKey={API_KEY} version="weekly">
              <Map
                defaultCenter={origin}
                defaultZoom={14}
                mapId="DEMO_MAP_ID"
                internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                style={{width: '100%', height: '100%', outline: 'none'}}
              >
                <AdvancedMarker position={origin} title="School Campus">
                  <Pin background="#10b981" glyphColor="#fff" />
                </AdvancedMarker>
                <AdvancedMarker position={destination} title="Last Stop">
                   <Pin background="#f43f5e" glyphColor="#fff" />
                </AdvancedMarker>
                <RouteDisplay origin={origin} destination={destination} waypoints={waypoints} />
              </Map>
            </APIProvider>
          )}
        </div>
      </div>

      {/* Safety Info Module */}
      <div className="space-y-4">
        <div className="bg-[#F9FAF7] p-5 rounded-2xl border border-[#E0E4D9] shadow-sm text-left">
          <h4 className="text-sm font-black text-slate-800 mb-3 flex items-center gap-2">
            <Bus className="h-4 w-4 text-emerald-600" /> Dispatch Details
          </h4>
          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center bg-white p-2.5 rounded-lg border border-slate-100">
              <span className="text-slate-500 font-sans font-semibold">Driver</span>
              <span className="text-slate-800 font-bold">{route.driverName}</span>
            </div>
            <div className="flex justify-between items-center bg-white p-2.5 rounded-lg border border-slate-100">
              <span className="text-slate-500 font-sans font-semibold">Mobile</span>
              <span className="text-slate-800 font-bold">{route.driverPhone}</span>
            </div>
            <div className="flex justify-between items-center bg-white p-2.5 rounded-lg border border-slate-100">
              <span className="text-slate-500 font-sans font-semibold">Attendant</span>
              <span className="text-slate-800 font-bold">Reshma Devi</span>
            </div>
            <div className="flex justify-between items-center bg-emerald-50 p-2.5 rounded-lg border border-emerald-100 text-emerald-800">
              <span className="font-sans font-bold flex items-center gap-1.5"><Shield className="h-3 w-3" /> Security Validated</span>
              <span><CheckCircle2 className="h-4 w-4" /></span>
            </div>
          </div>
        </div>

        {/* Dynamic ETA Tracking Card */}
        <div className={`p-5 rounded-2xl border shadow-sm text-center relative overflow-hidden transition-colors ${
          busStatus === 'Delayed' ? 'bg-amber-50 border-amber-100' : 'bg-white border-[#E0E4D9]'
        }`}>
          {busStatus === 'Delayed' && (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-amber-100 text-amber-800 text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> Traffic Commute Delay
            </div>
          )}
          
          <div className="flex items-center justify-center mt-3">
             <Clock className={`w-8 h-8 ${busStatus === 'Delayed' ? 'text-amber-500' : 'text-slate-400'} animate-pulse`} />
          </div>
          <div className="mt-2 flex flex-col items-center">
            <span className="text-4xl font-black font-mono tracking-tight text-slate-800">{eta}</span>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-1">Mins Away</span>
          </div>
        </div>
      </div>
    </div>
  );
}
