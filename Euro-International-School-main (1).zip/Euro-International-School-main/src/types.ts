/**
 * Type definitions for Euro International School Portal (Campus Pro)
 */

export type UserRole = 'ADMIN' | 'TEACHER' | 'PARENT' | 'STUDENT' | 'STAFF_TRANSPORT';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  password?: string;
  details?: {
    class?: string;
    rollNo?: string;
    employeeId?: string;
    designation?: string;
    phone?: string;
    busRoute?: string;
    gender?: 'Male' | 'Female' | 'Other';
    admissionNo?: string;
    assignedSubject?: string;
    classTeacherOf?: string;
  };
}

export interface Homework {
  id: string;
  title: string;
  subject: string;
  classAssigned: string;
  dueDate: string;
  description: string;
  teacherName: string;
  attachmentUrl?: string;
  submissionsCount?: number;
  submitted?: boolean;
}

export interface HomeworkSubmission {
  id: string;
  homeworkId: string;
  studentName: string;
  submissionDate: string;
  fileName: string;
  grade?: string;
  feedback?: string;
}

export interface Exam {
  id: string;
  title: string;
  class: string;
  subject: string;
  date: string;
  duration: string;
  syllabus: string;
  publishedResults?: Record<string, string>; // StudentName -> Grade/Marks
}

export interface TimetablePeriod {
  day: string; // 'Monday', 'Tuesday', etc.
  periods: {
    time: string;
    subject: string;
    teacher: string;
    room?: string;
    isLive?: boolean;
    meetingUrl?: string;
  }[];
}

export interface AttendanceRecord {
  date: string;
  status: 'Present' | 'Absent' | 'Late' | 'Half-Day';
  remarks?: string;
}

export interface StudentAttendance {
  studentId: string;
  studentName: string;
  rollNo: string;
  class: string;
  attendance: AttendanceRecord[];
}

export interface Circular {
  id: string;
  title: string;
  date: string;
  category: 'Academic' | 'Administrative' | 'Event' | 'Holiday';
  content: string;
  sender: string;
  attachmentName?: string;
}

export interface ImageGalleryItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  date: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  receiverId: string;
  content: string;
  timestamp: string;
}

export interface FeeInvoice {
  id: string;
  term: string;
  issueDate: string;
  dueDate: string;
  tuitionFee: number;
  activityFee: number;
  transportFee: number;
  examFee: number;
  totalAmount: number;
  paidAmount: number;
  status: 'Paid' | 'Unpaid' | 'Overdue';
  paymentHistory?: {
    date: string;
    amount: number;
    transactionId: string;
    method: string;
  }[];
}

export interface LeaveRequest {
  id: string;
  studentName: string;
  class: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  appliedOn: string;
  reviewedBy?: string;
  comments?: string;
}

export interface BusStop {
  id: string;
  name: string;
  scheduledTime: string;
  reached?: boolean;
}

export interface BusRoute {
  id: string;
  routeName: string;
  routeCode: string;
  driverName: string;
  driverPhone: string;
  attendantName: string;
  busNumber: string;
  currentLat: number;
  currentLng: number;
  status: 'In-Transit' | 'Delayed' | 'Completed' | 'Idle';
  etaMinutes: number;
  stops: BusStop[];
}
