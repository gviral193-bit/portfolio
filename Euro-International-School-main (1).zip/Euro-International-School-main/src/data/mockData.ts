import { 
  User, 
  Homework, 
  Exam, 
  TimetablePeriod, 
  StudentAttendance, 
  Circular, 
  ImageGalleryItem, 
  ChatMessage, 
  FeeInvoice, 
  LeaveRequest, 
  BusRoute 
} from '../types';

// Mock users for our portal simulator selector
export const mockUsers: Record<string, User> = {
  admin: {
    id: 'USR_ADMIN_01',
    name: 'Mr. Rajesh Sharma',
    email: 'admin@eurodharuhera.edu.in',
    role: 'ADMIN',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      designation: 'Managing Director & Super Admin',
      employeeId: 'EIS-ADM-001',
      phone: '+91 98765 43210'
    }
  },
  teacher: {
    id: 'USR_TEACH_01',
    name: 'Mrs. Sunita Rao',
    email: 'sunita.math@eurodharuhera.edu.in',
    role: 'TEACHER',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      class: 'Grade 10-A',
      designation: 'Head of Mathematics Department',
      employeeId: 'EIS-TCH-104',
      phone: '+91 98123 45678'
    }
  },
  parent: {
    id: 'USR_PARENT_01',
    name: 'Mr. Alok Kumar',
    email: 'alok.kumar@gmail.com',
    role: 'PARENT',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      class: 'Grade 10-A Parent',
      phone: '+91 94123 98765',
      busRoute: 'Route-5B (Sector-6)'
    }
  },
  student: {
    id: 'USR_STUDENT_01',
    name: 'Aarav Kumar',
    email: 'aarav.kumar@eurodharuhera.edu.in',
    role: 'STUDENT',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      class: 'Grade 10-A',
      rollNo: 'EIS-10A-14',
      phone: '+91 94123 98765',
      busRoute: 'Route-5B'
    }
  },
  staff_transport: {
    id: 'USR_STAFF_01',
    name: 'Mr. Vinod Yadav',
    email: 'transport@eurodharuhera.edu.in',
    role: 'STAFF_TRANSPORT',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    details: {
      designation: 'Admissions & Logistics Incharge',
      employeeId: 'EIS-STF-023',
      phone: '+91 99887 76655'
    }
  }
};

// Initial homework assignments list
export const initialHomework: Homework[] = [
  {
    id: 'HW-01',
    title: 'Quadratic Equations Practice Sheet',
    subject: 'Mathematics',
    classAssigned: 'Grade 10-A',
    dueDate: '2026-06-01',
    description: 'Solve problems 1 to 15 from Chapter 4 exercise sheet. Show all steps clearly. Focus on completing squares and using quadratic formula methods.',
    teacherName: 'Mrs. Sunita Rao',
    attachmentUrl: 'EIS_Math_Grade10_Quadratic_Sheet.pdf',
    submissionsCount: 22,
    submitted: false
  },
  {
    id: 'HW-02',
    title: 'Refraction & Lenses Assignment',
    subject: 'Physics',
    classAssigned: 'Grade 10-A',
    dueDate: '2026-05-31',
    description: 'Draw ray diagrams for concave and convex lenses under various object positions. Write short notes on Lens Maker Equation and Power of Lens.',
    teacherName: 'Mr. Devendra Singh',
    attachmentUrl: 'Physics_Ray_Diagrams_Assignment.pdf',
    submissionsCount: 19,
    submitted: true
  },
  {
    id: 'HW-03',
    title: 'Constitutional Design Analysis',
    subject: 'Social Science',
    classAssigned: 'Grade 10-A',
    dueDate: '2026-06-03',
    description: 'Summarize the core features of the Indian Constitution detailing the role of the constituent assembly and the preamble of India.',
    teacherName: 'Ms. Priya Verma',
    submissionsCount: 15,
    submitted: false
  },
  {
    id: 'HW-04',
    title: 'The Portrait of a Lady - Summary & Character Sketch',
    subject: 'English',
    classAssigned: 'Grade 10-A',
    dueDate: '2026-05-30',
    description: 'Submit an insightful character sketch of Khushwant Singh\'s grandmother emphasizing her daily schedule, her affinity with nature & sparrows.',
    teacherName: 'Mrs. Neha Mehra',
    submissionsCount: 24,
    submitted: true
  }
];

// Examinations Schedule and Mock Results
export const initialExams: Exam[] = [
  {
    id: 'EX-01',
    title: 'First Periodic Assessment (PA-1)',
    class: 'Grade 10-A',
    subject: 'Mathematics',
    date: '2026-06-15',
    duration: '1.5 Hours',
    syllabus: 'Chapter 1: Real Numbers, Chapter 2: Polynomials, Chapter 3: Pair of Linear Equations in Two Variables.',
    publishedResults: {
      'Aarav Kumar': '92%',
      'Diya Sharma': '95%',
      'Rohan Roy': '88%',
      'Sneha Gupta': '78%'
    }
  },
  {
    id: 'EX-02',
    title: 'First Periodic Assessment (PA-1)',
    class: 'Grade 10-A',
    subject: 'Science',
    date: '2026-06-16',
    duration: '1.5 Hours',
    syllabus: 'Physics: Light Reflection & Refraction; Chemistry: Chemical Reactions; Biology: Life Processes.',
    publishedResults: {
      'Aarav Kumar': '89%',
      'Diya Sharma': '91%',
      'Rohan Roy': '85%',
      'Sneha Gupta': '84%'
    }
  },
  {
    id: 'EX-03',
    title: 'First Periodic Assessment (PA-1)',
    class: 'Grade 10-A',
    subject: 'Social Science',
    date: '2026-06-17',
    duration: '1.5 Hours',
    syllabus: 'History: Nationalism in Europe; Geography: Resources and Development; Civics: Power Sharing.',
    publishedResults: {
      'Aarav Kumar': '95%',
      'Diya Sharma': '94%',
      'Rohan Roy': '90%',
      'Sneha Gupta': '91%'
    }
  }
];

// Interactive Weekly Timetable with Virtual Hooks
export const mockTimetablesByClass: Record<string, TimetablePeriod[]> = {
  'Grade 10-A': [
    {
      day: 'Monday',
      periods: [
        { time: '08:30 AM - 09:15 AM', subject: 'Mathematics', teacher: 'Mrs. Sunita Rao', room: 'Room 304', isLive: true, meetingUrl: 'https://meet.google.com/abc-defg-hij' },
        { time: '09:15 AM - 10:00 AM', subject: 'Physics', teacher: 'Mr. Devendra Singh', room: 'Lab 2A' },
        { time: '10:00 AM - 10:45 AM', subject: 'English', teacher: 'Mrs. Neha Mehra', room: 'Room 304' },
        { time: '11:15 AM - 12:00 PM', subject: 'Social Science', teacher: 'Ms. Priya Verma', room: 'Room 304' },
        { time: '12:00 PM - 12:45 PM', subject: 'Computer Applications', teacher: 'Mr. Amit Gupta', room: 'IT Lab 1', isLive: true, meetingUrl: 'https://meet.google.com/xyz-pqrs-tuv' }
      ]
    },
    {
      day: 'Tuesday',
      periods: [
        { time: '08:30 AM - 09:15 AM', subject: 'Chemistry', teacher: 'Mr. Devendra Singh', room: 'Chemistry Lab' },
        { time: '09:15 AM - 10:00 AM', subject: 'Mathematics', teacher: 'Mrs. Sunita Rao', room: 'Room 304' },
        { time: '10:00 AM - 10:45 AM', subject: 'Social Science', teacher: 'Ms. Priya Verma', room: 'Room 304' },
        { time: '11:15 AM - 12:00 PM', subject: 'Physical Education', teacher: 'Coach Satish', room: 'Main Playground' },
        { time: '12:00 PM - 12:45 PM', subject: 'Biology', teacher: 'Dr. Neeraj Khanna', room: 'Primary Lab' }
      ]
    },
    {
      day: 'Wednesday',
      periods: [
        { time: '08:30 AM - 09:15 AM', subject: 'Mathematics', teacher: 'Mrs. Sunita Rao', room: 'Room 304', isLive: true, meetingUrl: 'https://meet.google.com/abc-defg-hij' },
        { time: '09:15 AM - 10:00 AM', subject: 'English', teacher: 'Mrs. Neha Mehra', room: 'Room 304' },
        { time: '10:00 AM - 10:45 AM', subject: 'Physics', teacher: 'Mr. Devendra Singh', room: 'Room 304' },
        { time: '11:15 AM - 12:00 PM', subject: 'Hindi', teacher: 'Mrs. Saroj Bala', room: 'Room 304' },
        { time: '12:00 PM - 12:45 PM', subject: 'Music/Art', teacher: 'Mrs. Deepa Sunder', room: 'Vocal Studio' }
      ]
    },
    {
      day: 'Thursday',
      periods: [
        { time: '08:30 AM - 09:15 AM', subject: 'Social Science', teacher: 'Ms. Priya Verma', room: 'Room 304' },
        { time: '09:15 AM - 10:00 AM', subject: 'Biology', teacher: 'Dr. Neeraj Khanna', room: 'Bio Lab' },
        { time: '10:00 AM - 10:45 AM', subject: 'Mathematics', teacher: 'Mrs. Sunita Rao', room: 'Room 304' },
        { time: '11:15 AM - 12:00 PM', subject: 'English', teacher: 'Mrs. Neha Mehra', room: 'Room 304' },
        { time: '12:00 PM - 12:45 PM', subject: 'Library Hour', teacher: 'Mrs. Kanta Chawla', room: 'Central Library' }
      ]
    },
    {
      day: 'Friday',
      periods: [
        { time: '08:30 AM - 09:15 AM', subject: 'Hindi', teacher: 'Mrs. Saroj Bala', room: 'Room 304' },
        { time: '09:15 AM - 10:00 AM', subject: 'Chemistry', teacher: 'Mr. Devendra Singh', room: 'Room 304' },
        { time: '10:00 AM - 10:45 AM', subject: 'Mathematics', teacher: 'Mrs. Sunita Rao', room: 'Room 304', isLive: true, meetingUrl: 'https://meet.google.com/abc-defg-hij' },
        { time: '11:15 AM - 12:00 PM', subject: 'Social Science', teacher: 'Ms. Priya Verma', room: 'Room 304' },
        { time: '12:00 PM - 12:45 PM', subject: 'Computer Applications', teacher: 'Mr. Amit Gupta', room: 'IT Lab 1' }
      ]
    }
  ]
};

// Realistic mock calendar of monthly school attendance for Aarav Kumar (Parent dashboard use)
export const parentStudentAttendance: StudentAttendance = {
  studentId: 'USR_STUDENT_01',
  studentName: 'Aarav Kumar',
  rollNo: 'EIS-10A-14',
  class: 'Grade 10-A',
  attendance: [
    { date: '2026-05-01', status: 'Present' },
    { date: '2026-05-04', status: 'Present' },
    { date: '2026-05-05', status: 'Present' },
    { date: '2026-05-06', status: 'Present' },
    { date: '2026-05-07', status: 'Absent', remarks: 'Fever. Applied via portal.' },
    { date: '2026-05-08', status: 'Present' },
    { date: '2026-05-11', status: 'Present' },
    { date: '2026-05-12', status: 'Present' },
    { date: '2026-05-13', status: 'Late', remarks: 'Late due to bad weather' },
    { date: '2026-05-14', status: 'Present' },
    { date: '2026-05-15', status: 'Present' },
    { date: '2026-05-18', status: 'Present' },
    { date: '2026-05-19', status: 'Present' },
    { date: '2026-05-20', status: 'Present' },
    { date: '2026-05-21', status: 'Present' },
    { date: '2026-05-22', status: 'Present' },
    { date: '2026-05-25', status: 'Present' },
    { date: '2026-05-26', status: 'Present' },
    { date: '2026-05-27', status: 'Present' },
    { date: '2026-05-28', status: 'Present' }, // Today!
  ]
};

// Notice board notices / Circulars
export const initialCirculars: Circular[] = [
  {
    id: 'CIRC-102',
    title: 'Postponement of PA-1 Examinations due to Intense Summer Heatwave',
    date: '2026-05-26',
    category: 'Academic',
    content: 'Dear Parents & Students,\n\nIn compliance with the recent directive from the Directorate of Education regarding extreme heat conditions, all Periodic Assessment-1 examinations starting June 5th have being rescheduled to June 15th. Detailed revised timetables have been updated under the Examinations module of the portal.\n\nKeep cool and hydrated.',
    sender: 'Office of the Principal',
    attachmentName: 'Revised_PA1_Scedule.pdf'
  },
  {
    id: 'CIRC-101',
    title: 'Admissions Open for Session 2026-27 (Pre-Nursery to Grade XI)',
    date: '2026-05-20',
    category: 'Administrative',
    content: 'Euro International School, Dharuhera begins its main registration phase for the upcoming academic cohort. Euro-curriculum balances tech integration, global values, and sports facilities. Existing parents referring families receive an active reference waiver benefits.',
    sender: 'Director of Admissions',
    attachmentName: 'Prospectus_EIS_2026.pdf'
  },
  {
    id: 'CIRC-103',
    title: 'Annual Inter-School Robotics Championship (Robofest 2026) Launch',
    date: '2026-05-18',
    category: 'Event',
    content: 'EIS is hosting the District Robofest 2026 on June 29th. Categories include Line Follower Robot, Drag Racing, and Waste Repurposed Drone models. Interested Grade 6-12 groups are instructed to submit concept notes to the Science HOD, Dr. Devendra, by June 8th.',
    sender: 'HOD Technology & Innovation',
    attachmentName: 'Robofest_Brochure_Rules.pdf'
  },
  {
    id: 'CIRC-99',
    title: 'School Bus Route #5B Time Optimization Alert',
    date: '2026-05-14',
    category: 'Holiday',
    content: 'To prevent commute bottlenecks near the NH-48 bypass, Bus route 5B (covering Sector-6 and premium stops) is advanced by 7 minutes from Monday. Please refer to updated stop timings under the transport portal. Attendant details remain unchanged.',
    sender: 'Transport Logistics Operations'
  }
];

// Gallery Images
export const initialGallery: ImageGalleryItem[] = [
  {
    id: 'GAL-01',
    title: 'Advanced Science and STEM Lab',
    category: 'Academics',
    imageUrl: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80',
    date: '2026-04-12'
  },
  {
    id: 'GAL-02',
    title: 'Inter-House Athletic Meet Gold Honors',
    category: 'Sports',
    imageUrl: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=800&q=80',
    date: '2026-05-02'
  },
  {
    id: 'GAL-03',
    title: 'Collaborative Coding Workshop & IT Hub',
    category: 'Campus Facilities',
    imageUrl: 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80',
    date: '2026-05-15'
  },
  {
    id: 'GAL-04',
    title: 'Euro Model United Nations (MUN) General Assembly',
    category: 'Co-Curricular',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
    date: '2026-04-28'
  },
  {
    id: 'GAL-05',
    title: 'Central Library & Reading Circle',
    category: 'Campus Facilities',
    imageUrl: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-10'
  }
];

// Chat conversations
export const initialMessages: ChatMessage[] = [
  {
    id: 'M-01',
    senderId: 'USR_TEACH_01',
    senderName: 'Mrs. Sunita Rao',
    senderRole: 'TEACHER',
    receiverId: 'USR_PARENT_01',
    content: 'Hello Mr. Kumar, I wanted to discuss Aarav\'s recent performance in Maths. In the PA-1 test prep quiz, he did excellent in calculations, but faced minor speed issues with word problems. He should practice solving quadratic equations against a 40-minute timer at home.',
    timestamp: '2026-05-27 15:40'
  },
  {
    id: 'M-02',
    senderId: 'USR_PARENT_01',
    senderName: 'Mr. Alok Kumar',
    senderRole: 'PARENT',
    receiverId: 'USR_TEACH_01',
    content: 'Thank you for tracking him so closely, Ma\'am. Yes, Aarav also mentioned he got a bit nervous with long worded formulas. I have downloaded the quadratic assignment you posted. I will make sure he solves it under timed supervision this weekend.',
    timestamp: '2026-05-27 18:15'
  },
  {
    id: 'M-03',
    senderId: 'USR_TEACH_01',
    senderName: 'Mrs. Sunita Rao',
    senderRole: 'TEACHER',
    receiverId: 'USR_PARENT_01',
    content: 'Splendid. Happy to help! He is a very attentive child and catches concepts rapidly. Do remind him to submit the refraction homework by May 31st as well.',
    timestamp: '2026-05-28 09:30'
  }
];

// Fee structure and detailed breakdowns for Parent Alok Kumar (Aarav Grade 10)
export const initialInvoices: FeeInvoice[] = [
  {
    id: 'INV-2026-Q1',
    term: 'Quarter 1 Academic Fee (Apr - Jun 2026)',
    issueDate: '2026-04-01',
    dueDate: '2026-04-15',
    tuitionFee: 24500,
    activityFee: 3200,
    transportFee: 4500,
    examFee: 1200,
    totalAmount: 33400,
    paidAmount: 33400,
    status: 'Paid',
    paymentHistory: [
      {
        date: '2026-04-08 11:24',
        amount: 33400,
        transactionId: 'TXN-HDFC-993820491',
        method: 'NetBanking / Credit Card'
      }
    ]
  },
  {
    id: 'INV-2026-Q2',
    term: 'Quarter 2 Academic Fee (Jul - Sep 2026)',
    issueDate: '2026-07-01',
    dueDate: '2026-07-15',
    tuitionFee: 24500,
    activityFee: 3200,
    transportFee: 4500,
    examFee: 1200,
    totalAmount: 33400,
    paidAmount: 0,
    status: 'Unpaid'
  }
];

// Leave applications applied
export const initialLeaves: LeaveRequest[] = [
  {
    id: 'L-01',
    studentName: 'Aarav Kumar',
    class: 'Grade 10-A',
    startDate: '2026-05-07',
    endDate: '2026-05-07',
    reason: 'Suffering from sudden onset of seasonal fever. Requested relaxation of physical attendance.',
    status: 'Approved',
    appliedOn: '2026-05-06',
    reviewedBy: 'Mrs. Sunita Rao (Grade 10 Mentor)',
    comments: 'Approved. Get rest, Aarav. Catch up on Ray Diagrams when back.'
  },
  {
    id: 'L-02',
    studentName: 'Aarav Kumar',
    class: 'Grade 10-A',
    startDate: '2026-06-05',
    endDate: '2026-06-06',
    reason: 'Attending elder sibling\'s wedding ceremony in Jaipur. Leave permission is requested for two working days.',
    status: 'Pending',
    appliedOn: '2026-05-28'
  }
];

// Transport Route 5B details & stop progression
export const mockBusRoute: BusRoute = {
  id: 'RT-5B',
  routeName: 'Dharuhera Sector-6 Elite Lines',
  routeCode: 'Route-5B',
  driverName: 'Mr. Satpal Singh',
  driverPhone: '+91 94433 22110',
  attendantName: 'Mrs. Bimla Devi',
  busNumber: 'HR-26-EA-7781',
  currentLat: 28.2045,  // Interactive mock simulation location
  currentLng: 76.8123,
  status: 'In-Transit',
  etaMinutes: 12,
  stops: [
    { id: 'S1', name: 'EIS Dharuhera Campus', scheduledTime: '07:30 AM / 02:40 PM', reached: true },
    { id: 'S2', name: 'Altech Crossing Intersection', scheduledTime: '07:42 AM / 02:52 PM', reached: true },
    { id: 'S3', name: 'Sector-6 Apex Premium Plaza', scheduledTime: '07:55 AM / 03:05 PM', reached: true },
    { id: 'S4', name: 'Aarav Kumar Residential Gate', scheduledTime: '08:05 AM / 03:15 PM', reached: false }, // Parent Stop!
    { id: 'S5', name: 'Beniwal Crossing Turn', scheduledTime: '08:15 AM / 03:25 PM', reached: false },
    { id: 'S6', name: 'Shanti Kunj Gate D-Cluster', scheduledTime: '08:23 AM / 03:33 PM', reached: false }
  ]
};
