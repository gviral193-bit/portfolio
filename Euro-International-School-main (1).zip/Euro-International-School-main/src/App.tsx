import { useState } from 'react';
import { SchoolWebsite } from './components/SchoolWebsite';
import { PortalSimulator } from './components/PortalSimulator';

export default function App() {
  const [inPortalMode, setInPortalMode] = useState(false);

  return (
    <div className="min-h-screen bg-slate-100">
      {inPortalMode ? (
        <PortalSimulator onExitPortal={() => setInPortalMode(false)} />
      ) : (
        <SchoolWebsite onEnterPortal={() => setInPortalMode(true)} />
      )}
    </div>
  );
}
