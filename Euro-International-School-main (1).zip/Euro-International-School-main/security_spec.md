# Security Spec

## Data Invariants
1. A user can only access their own profile.
2. Admins can read all documents and write all documents.
3. Teachers can create homeworks, exams, circulars, and grade assignments.
4. Students/Parents can read homeworks, exams, circulars, their own attendance, invoices, and leaves.
5. Students can submit homework.
6. Messages can only be read/written by the sender or receiver.

## The Dirty Dozen Payloads
1. User profile creation with mismatched UID.
2. Updating `role` to ADMIN by a non-admin user.
3. Teacher creating a homework assignment for a class they don't teach.
4. Student modifying their own homework grade.
5. Student submitting homework for another student.
6. Non-admin modifying exam results.
7. Student reading another student's attendance.
8. Non-teacher/admin creating a circular.
9. User sending a message with a spoofed senderId.
10. User reading a message they are not a participant of.
11. Student modifying an invoice status to "Paid".
12. Student deleting an exam document.
