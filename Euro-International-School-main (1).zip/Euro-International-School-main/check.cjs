const https = require('https');
const checkUrl = (url) => {
  https.get(url, (res) => {
    console.log(url, res.statusCode, res.headers['content-type']);
  }).on('error', (e) => {
    console.error(url, e.message);
  });
};
checkUrl('https://euroschooldharuhera.com/wp-content/uploads/2021/08/logo.png');
checkUrl('https://euroschoolsec84ggn.com/wp-content/uploads/2023/05/cropped-Euro-Logo-1.png');
checkUrl('https://euroschoolsec84ggn.com/wp-content/uploads/2022/10/logo.png');
checkUrl('https://euroschoolsec84ggn.com/wp-content/uploads/2023/05/Euro-Logo-1.png');
